package com.pulse.player.data

import okhttp3.Request
import org.json.JSONObject
import org.schabi.newpipe.extractor.services.soundcloud.SoundcloudParsingHelper
import java.io.IOException

/** Твой аккаунт SoundCloud: профиль и лайки (через веб-API SoundCloud). */
class SoundCloudAccount(private val tokenProvider: () -> String?) {

    private val base = "https://api-v2.soundcloud.com"
    @Volatile private var userId: Long? = null

    private fun get(path: String): JSONObject {
        val token = tokenProvider() ?: throw IOException("SoundCloud: нужно войти в аккаунт")
        val clientId = SoundcloudParsingHelper.clientId()
        val sep = if ('?' in path) '&' else '?'
        val req = Request.Builder()
            .url("$base$path${sep}client_id=$clientId")
            .header("Authorization", "OAuth $token")
            .header("User-Agent", Http.UA)
            .build()
        Http.client.newCall(req).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (r.code == 401 || r.code == 403) throw IOException("SoundCloud: войди в аккаунт заново")
            if (!r.isSuccessful) throw IOException("SoundCloud: ошибка ${r.code}")
            return JSONObject(text)
        }
    }

    fun reset() {
        userId = null
    }

    fun me(): String {
        val o = get("/me")
        userId = o.optLong("id")
        return o.optString("username").ifBlank { "Аккаунт SoundCloud" }
    }

    fun likes(): List<Track> {
        val id = userId ?: run { me(); userId } ?: throw IOException("SoundCloud: профиль не найден")
        val arr = get("/users/$id/track_likes?limit=200&linked_partitioning=1").optJSONArray("collection")
            ?: return emptyList()
        return (0 until arr.length()).mapNotNull { toTrack(arr.optJSONObject(it)?.optJSONObject("track")) }
    }

    private fun toTrack(t: JSONObject?): Track? {
        if (t == null) return null
        val url = t.optString("permalink_url")
        if (url.isBlank()) return null
        val art = t.optString("artwork_url").takeIf { it.isNotBlank() && it != "null" }
            ?: t.optJSONObject("user")?.optString("avatar_url")
        return Track(
            id = url,
            source = Source.SOUNDCLOUD,
            title = t.optString("title"),
            artist = t.optJSONObject("user")?.optString("username").orEmpty(),
            coverUrl = art?.replace("-large.", "-t500x500."),
            durationMs = t.optLong("duration"),
        )
    }
}
