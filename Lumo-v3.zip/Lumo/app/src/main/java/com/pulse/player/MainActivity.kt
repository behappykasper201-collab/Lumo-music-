package com.pulse.player

import android.Manifest
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.pulse.player.data.Eggs
import com.pulse.player.data.Phrases
import com.pulse.player.ui.EggOverlay
import com.pulse.player.ui.EggOverlayLayer
import com.pulse.player.ui.SplashScreen
import kotlinx.coroutines.flow.map
import kotlin.math.sqrt
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pulse.player.data.AppSettings
import com.pulse.player.ui.HomeScreen
import com.pulse.player.ui.LoginScreen
import com.pulse.player.ui.LoginService
import com.pulse.player.ui.LibraryScreen
import androidx.compose.material.icons.rounded.LibraryMusic
import com.pulse.player.ui.MiniPlayer
import com.pulse.player.ui.PlayerScreen
import com.pulse.player.ui.PulseBackground
import com.pulse.player.ui.PulseTheme
import com.pulse.player.ui.SearchScreen
import com.pulse.player.ui.SettingsScreen
import com.pulse.player.ui.rememberCoverColor
import com.pulse.player.ui.effectiveBg
import com.pulse.player.ui.panelColor

class MainActivity : ComponentActivity() {

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val app = application as PulseApp
        setContent { PulseRoot(app) }
    }
}

@Composable
fun PulseRoot(app: PulseApp) {
    val loaded by app.settings.flow.map<AppSettings, AppSettings?> { it }
        .collectAsStateWithLifecycle(initialValue = null)
    val settings = loaded ?: AppSettings()
    val ps by app.player.state.collectAsStateWithLifecycle()
    val coverColor = rememberCoverColor(ps.artwork)
    val ctx = LocalContext.current

    // Потряси телефон — пасхалка
    LifecycleResumeEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        var last = 0L
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val x = e.values[0]
                val y = e.values[1]
                val z = e.values[2]
                val g = sqrt(x * x + y * y + z * z)
                val now = SystemClock.elapsedRealtime()
                if (g > 32f && now - last > 2500) {
                    last = now
                    app.onShake()
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (acc != null) sm.registerListener(listener, acc, SensorManager.SENSOR_DELAY_UI)
        onPauseOrDispose { sm.unregisterListener(listener) }
    }

    PulseTheme(settings, coverColor) {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        var playerOpen by rememberSaveable { mutableStateOf(false) }
        var loginFor by rememberSaveable { mutableStateOf<LoginService?>(null) }
        var splashDone by rememberSaveable { mutableStateOf(false) }
        val greeting = remember(app.replaySplash) { Phrases.greeting() }
        val snackbar = remember { SnackbarHostState() }

        LaunchedEffect(Unit) {
            app.messages.collect { snackbar.showSnackbar(it) }
        }
        LaunchedEffect(app.replaySplash) {
            if (app.replaySplash > 0) splashDone = false
        }

        val rotation by animateFloatAsState(
            app.spins * 360f, tween(1400, easing = FastOutSlowInEasing), label = "barrelRoll",
        )

        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            if (loaded != null) {

            Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = rotation }) {
                PulseBackground(effectiveBg(settings), ps.artwork, settings.animSpeed)

                Scaffold(
                    containerColor = Color.Transparent,
                    snackbarHost = { SnackbarHost(snackbar) },
                    bottomBar = {
                        Column {
                            AnimatedVisibility(ps.hasItem, enter = slideInVertically { it } + fadeIn(), exit = fadeOut()) {
                                MiniPlayer(app, ps, settings) { playerOpen = true }
                            }
                            NavigationBar(containerColor = panelColor()) {
                                val items = listOf(
                                    Triple("Главная", Icons.Rounded.Home, 0),
                                    Triple("Поиск", Icons.Rounded.Search, 1),
                                    Triple("Медиатека", Icons.Rounded.LibraryMusic, 2),
                                    Triple("Вид", Icons.Rounded.Tune, 3),
                                )
                                items.forEach { (label, icon, index) ->
                                    NavigationBarItem(
                                        selected = tab == index,
                                        onClick = { tab = index },
                                        icon = { Icon(icon, label) },
                                        label = { Text(label) },
                                    )
                                }
                            }
                        }
                    },
                ) { padding ->
                    Crossfade(tab, Modifier.padding(padding), label = "tabs") { current ->
                        when (current) {
                            0 -> HomeScreen(app, settings)
                            1 -> SearchScreen(app, settings)
                            2 -> LibraryScreen(app, settings)
                            else -> SettingsScreen(app, settings, onLogin = { loginFor = it })
                        }
                    }
                }

                AnimatedVisibility(
                    visible = playerOpen && ps.hasItem,
                    enter = slideInVertically { it } + fadeIn(),
                    exit = slideOutVertically { it } + fadeOut(),
                ) {
                    PlayerScreen(app, ps, settings, onClose = { playerOpen = false })
                }

                loginFor?.let { service ->
                    LoginScreen(
                        service = service,
                        onToken = { token ->
                            if (loginFor != null) {
                                loginFor = null
                                when (service) {
                                    LoginService.YANDEX -> {
                                        app.login(token)
                                        app.toast("Яндекс подключён")
                                    }
                                    LoginService.SOUNDCLOUD -> app.loginSoundCloud(token)
                                }
                            }
                        },
                        onClose = { loginFor = null },
                    )
                }
            }

            EggOverlayLayer(app.overlay)

            AnimatedVisibility(
                visible = !splashDone && (settings.splash || app.replaySplash > 0),
                enter = fadeIn(),
                exit = fadeOut(tween(600)) + scaleOut(targetScale = 1.08f, animationSpec = tween(600)),
            ) {
                SplashScreen(greeting) {
                    if (!splashDone) {
                        splashDone = true
                        greeting.eggId?.let { Eggs.find(it) }
                        if (greeting.eggId == "new_year") app.showOverlay(EggOverlay.SNOW, 20000)
                        if (greeting.eggId == "halloween") app.showOverlay(EggOverlay.MATRIX, 6000)
                    }
                }
            }
            }
        }

        BackHandler(playerOpen || loginFor != null) {
            if (loginFor != null) loginFor = null else playerOpen = false
        }
    }
}
