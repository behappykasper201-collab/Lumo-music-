package com.pulse.player

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.pulse.player.data.LocalLibrary
import com.pulse.player.data.LocalPlaylist
import com.pulse.player.data.Secure
import com.pulse.player.data.SettingsStore
import com.pulse.player.data.SoundCloudAccount
import com.pulse.player.data.SpotifyImport
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import com.pulse.player.data.Eggs
import com.pulse.player.data.Phrases
import com.pulse.player.data.SoundCloud
import com.pulse.player.data.Taste
import com.pulse.player.data.Source
import com.pulse.player.data.Track
import com.pulse.player.data.YandexMusic
import com.pulse.player.data.toMediaItem
import com.pulse.player.playback.PlayerConnection
import com.pulse.player.playback.Wave
import com.pulse.player.playback.WaveConfig
import com.pulse.player.ui.EggOverlay
import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SearchModel {
    var query by mutableStateOf("")
    var source by mutableStateOf(Source.YANDEX)
    var results by mutableStateOf<List<Track>>(emptyList())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
}

/** Состояние вкладки «Медиатека». */
class LibraryModel {
    var yaPlaylists by mutableStateOf<List<YandexMusic.Playlist>>(emptyList())
    var local by mutableStateOf<List<LocalPlaylist>>(emptyList())
    var opened by mutableStateOf<OpenedList?>(null)
    var importing by mutableStateOf<String?>(null) // текст прогресса импорта
}

data class OpenedList(val title: String, val subtitle: String, val tracks: List<Track>, val loading: Boolean, val localId: String? = null)

class PulseApp : Application() {

    lateinit var settings: SettingsStore
        private set

    val isLoggedIn: Boolean get() = Secure.yandex != null
    val scLoggedIn: Boolean get() = Secure.soundcloud != null

    val yandex = YandexMusic { Secure.yandex }
    val scAccount = SoundCloudAccount { Secure.soundcloud }
    val library = LibraryModel()

    /** Подключённые сервисы — для экрана (Compose следит за изменениями). */
    var tokens by mutableStateOf(Secure.Tokens())
        private set
    var scName by mutableStateOf<String?>(null)
        private set
    val player by lazy { PlayerConnection(this) }
    val scope = MainScope()
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val search = SearchModel()

    var accountName by mutableStateOf<String?>(null)
        private set
    var waveLoading by mutableStateOf(false)
        private set
    var preparingId by mutableStateOf<String?>(null)
        private set
    /** Меняется при лайке/дизлайке, чтобы экран перерисовал сердечко. */
    var reactionVersion by mutableIntStateOf(0)
        private set

    // ---------- пасхалки ----------
    var overlay by mutableStateOf<EggOverlay?>(null)
        private set
    var spins by mutableIntStateOf(0)
        private set
    var replaySplash by mutableIntStateOf(0)
        private set
    private var overlayJob: Job? = null
    private val waveTaps = ArrayDeque<Long>()

    fun showOverlay(kind: EggOverlay, ms: Long = 8000) {
        overlay = kind
        overlayJob?.cancel()
        overlayJob = scope.launch {
            delay(ms)
            overlay = null
        }
    }

    fun barrelRoll() {
        spins++
    }

    fun onShake() {
        Eggs.find("shake")
        showOverlay(EggOverlay.CONFETTI, 3500)
        toast(Phrases.shake.random())
    }

    /** Секретные слова в поиске. true — поиск не запускаем. */
    private fun secretSearch(q: String): Boolean {
        when (q) {
            "lumo", "люмо", "lumo music" -> {
                Eggs.find("search_lumo")
                toast("Это я! Приятно, что ищешь 🙂")
                return true
            }
            "42" -> {
                Eggs.find("search_42")
                toast("Ответ найден. Осталось понять вопрос 🌌")
                return true
            }
            "dvd" -> {
                Eggs.find("search_dvd")
                showOverlay(EggOverlay.DVD, 20000)
                toast("Ждём, когда попадёт ровно в угол…")
                return true
            }
            "snow", "снег", "снегопад", "зима" -> {
                Eggs.find("search_snow")
                showOverlay(EggOverlay.SNOW, 15000)
                return true
            }
            "party", "вечеринка", "тусовка", "туса" -> {
                Eggs.find("search_party")
                showOverlay(EggOverlay.CONFETTI, 8000)
                toast("Вечеринка начинается! 🎉")
                return true
            }
            "do a barrel roll", "barrel roll", "бочка", "сделай бочку" -> {
                Eggs.find("search_roll")
                barrelRoll()
                return true
            }
            "hello world", "hello, world", "привет мир" -> {
                Eggs.find("search_hello")
                replaySplash++
                return true
            }
            "пасхалка", "пасхалки", "easter egg", "секрет" -> {
                Eggs.find("search_egg")
                toast("Ищешь пасхалки? Попробуй потрясти телефон или понажимать на логотип 😉")
                return true
            }
            "matrix", "матрица", "red pill", "красная таблетка" -> {
                Eggs.find("search_matrix")
                showOverlay(EggOverlay.MATRIX, 12000)
                toast("Проснись, Нео…")
                return true
            }
            "love", "любовь", "❤", "❤️", "люблю" -> {
                Eggs.find("search_love")
                showOverlay(EggOverlay.HEARTS, 8000)
                toast("Музыка тоже тебя любит ❤")
                return true
            }
        }
        if (q.contains("rick astley") || q.contains("never gonna") || q.contains("рикролл") || q == "rickroll") {
            Eggs.find("search_rick")
            toast("Ты знаешь правила. И я тоже 🕺")
            barrelRoll()
            return false // песню всё равно ищем
        }
        return false
    }

    private var searchJob: Job? = null
    private var playJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        settings = SettingsStore(this)
        Taste.init(this)
        Eggs.init(this)
        Secure.init(this)
        LocalLibrary.init(this)
        library.local = LocalLibrary.load()
        runCatching { SoundCloud.init() }

        // следим за подключёнными аккаунтами
        scope.launch {
            Secure.state.collect { t ->
                val yaChanged = t.yandex != tokens.yandex
                val scChanged = t.soundcloud != tokens.soundcloud
                tokens = t
                if (yaChanged || accountName == null) refreshAccount()
                if (scChanged || scName == null) refreshSoundCloud()
            }
        }

        scope.launch {
            var first = true
            settings.flow.collect {
                // переносим старый токен из обычных настроек в зашифрованное хранилище
                if (it.yandexToken != null) {
                    if (Secure.yandex == null) Secure.yandex = it.yandexToken
                    settings.update { s -> s.copy(yandexToken = null) }
                }

                val cfg = WaveConfig(it.waveMood, it.waveDiversity, it.waveLanguage, it.scShare)
                val cfgChanged = cfg != Wave.config
                Wave.config = cfg
                // поменяли настройки волны во время игры — перезапускаем с новыми
                if (!first && cfgChanged && Wave.active) startWave()
                first = false
            }
        }
    }

    fun toast(message: String) {
        messages.tryEmit(message)
    }

    private fun refreshAccount() {
        if (Secure.yandex == null) {
            accountName = null
            library.yaPlaylists = emptyList()
            return
        }
        scope.launch {
            accountName = try {
                withContext(Dispatchers.IO) { yandex.accountName() }
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun refreshSoundCloud() {
        scAccount.reset()
        if (Secure.soundcloud == null) {
            scName = null
            return
        }
        scope.launch {
            scName = try {
                withContext(Dispatchers.IO) { scAccount.me() }
            } catch (e: Exception) {
                null
            }
        }
    }

    fun login(token: String) {
        Secure.yandex = token
    }

    fun logout() {
        Secure.yandex = null
    }

    fun loginSoundCloud(token: String) {
        Secure.soundcloud = token
        toast("SoundCloud подключён")
    }

    fun logoutSoundCloud() {
        Secure.soundcloud = null
    }

    // ---------- Медиатека ----------

    fun refreshLibrary() {
        library.local = LocalLibrary.load()
        if (!isLoggedIn) return
        scope.launch {
            try {
                library.yaPlaylists = withContext(Dispatchers.IO) { yandex.playlists() }
            } catch (e: Exception) {
                // не страшно — покажем то, что есть
            }
        }
    }

    private fun openList(title: String, subtitle: String, localId: String? = null, load: suspend () -> List<Track>) {
        library.opened = OpenedList(title, subtitle, emptyList(), loading = true, localId = localId)
        scope.launch {
            try {
                val tracks = withContext(Dispatchers.IO) { load() }
                if (library.opened?.title == title) library.opened = OpenedList(title, subtitle, tracks, false, localId)
                if (tracks.isEmpty()) toast("Здесь пока пусто")
            } catch (e: Exception) {
                library.opened = null
                toast(e.message ?: "Не удалось загрузить")
            }
        }
    }

    fun openYandexLikes() = openList("Мне нравится", "Яндекс Музыка") { yandex.likedTracks() }

    fun openYandexPlaylist(p: YandexMusic.Playlist) = openList(p.title, "Плейлист · Яндекс Музыка") { yandex.playlistTracks(p.kind) }

    fun openSoundCloudLikes() = openList("Лайки", "SoundCloud") { scAccount.likes() }

    fun openLocal(p: LocalPlaylist) {
        library.opened = OpenedList(p.title, p.origin, p.tracks, false, p.id)
    }

    fun deleteLocal(id: String) {
        val list = library.local.filter { it.id != id }
        LocalLibrary.save(list)
        library.local = list
        library.opened = null
        toast("Плейлист удалён")
    }

    /** Импорт из Spotify: читаем плейлист и ищем каждый трек в Яндексе (или SoundCloud). */
    fun importSpotify(link: String) {
        if (library.importing != null) return
        library.importing = "Читаю плейлист…"
        scope.launch {
            try {
                val (name, items) = withContext(Dispatchers.IO) { SpotifyImport.fetch(link) }
                val useYandex = isLoggedIn
                val found = arrayOfNulls<Track>(items.size)
                var done = 0
                val gate = Semaphore(4)
                coroutineScope {
                    items.forEachIndexed { i, item ->
                        launch(Dispatchers.IO) {
                            gate.withPermit {
                                val q = "${item.artist.substringBefore(",")} ${item.title}"
                                found[i] = runCatching {
                                    val ya = if (useYandex) yandex.search(q).firstOrNull() else null
                                    ya ?: SoundCloud.search(q).firstOrNull()
                                }.getOrNull()
                                withContext(Dispatchers.Main) {
                                    done++
                                    library.importing = "Ищу треки: $done из ${items.size}"
                                }
                            }
                        }
                    }
                }
                val tracks = found.filterNotNull()
                if (tracks.isEmpty()) {
                    toast("Не нашёл ни одного трека 😕")
                } else {
                    val p = LocalPlaylist(System.currentTimeMillis().toString(), name, "Из Spotify · ${tracks.size} треков", tracks)
                    val list = listOf(p) + library.local
                    withContext(Dispatchers.IO) { LocalLibrary.save(list) }
                    library.local = list
                    toast("Готово! Нашёл ${tracks.size} из ${items.size} треков")
                }
            } catch (e: Exception) {
                toast(e.message ?: "Не удалось импортировать")
            } finally {
                library.importing = null
            }
        }
    }

    fun runSearch() {
        val q = search.query.trim()
        if (q.isEmpty()) return
        if (secretSearch(q.lowercase())) return
        val src = search.source
        searchJob?.cancel()
        search.loading = true
        search.error = null
        searchJob = scope.launch {
            try {
                val found = withContext(Dispatchers.IO) {
                    if (src == Source.YANDEX) yandex.search(q) else SoundCloud.search(q)
                }
                search.results = found
                if (found.isEmpty()) search.error = "Ничего не нашлось"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                search.results = emptyList()
                search.error = e.message ?: "Ошибка поиска"
            } finally {
                if (isActive) search.loading = false
            }
        }
    }

    /** Играет список, начиная с трека index. */
    fun play(list: List<Track>, index: Int) {
        val track = list.getOrNull(index) ?: return
        Wave.active = false
        playJob?.cancel()

        val hasYandex = list.any { it.source == Source.YANDEX }
        if (hasYandex && !isLoggedIn) {
            toast("Сначала войди в Яндекс — «Вид → Аккаунты»")
            if (track.source == Source.YANDEX) return
        }

        // Только Яндекс — ставим всю очередь сразу
        if (list.all { it.source == Source.YANDEX }) {
            player.setItems(list.map { it.toMediaItem() }, index)
            return
        }

        // Есть SoundCloud: ссылки получаем по порядку, очередь растёт в фоне
        preparingId = track.id
        playJob = scope.launch {
            try {
                suspend fun item(t: Track): androidx.media3.common.MediaItem? =
                    if (t.source == Source.YANDEX) {
                        if (isLoggedIn) t.toMediaItem() else null
                    } else {
                        try {
                            val (url, hls) = withContext(Dispatchers.IO) { SoundCloud.resolve(t.id) }
                            t.toMediaItem(url, hls)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            null
                        }
                    }

                val first = item(track) ?: throw java.io.IOException("трек недоступен")
                player.setItems(listOf(first), 0)
                preparingId = null
                for (next in list.drop(index + 1).take(40)) {
                    ensureActive()
                    val mi = item(next) ?: continue
                    player.addItems(listOf(mi))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast("SoundCloud: ${e.message ?: "ошибка"}")
            } finally {
                if (preparingId == track.id) preparingId = null
            }
        }
    }

    fun startWave() {
        val now = System.currentTimeMillis()
        waveTaps.addLast(now)
        while (waveTaps.isNotEmpty() && now - waveTaps.first() > 20_000) waveTaps.removeFirst()
        if (waveTaps.size >= 5) Eggs.find("wave_spam")
        if (waveLoading) return
        playJob?.cancel()
        waveLoading = true
        scope.launch {
            try {
                Wave.reset()
                val logged = isLoggedIn
                if (logged) {
                    val c = Wave.config
                    withContext(Dispatchers.IO) {
                        yandex.setWaveSettings(c.mood.api, c.diversity.api, c.language.api)
                    }
                }
                val items = withContext(Dispatchers.IO) { Wave.buildBatch(yandex, logged, null, emptySet()) }
                if (items.isEmpty()) {
                    toast("Волна пока пустая, попробуй ещё раз")
                } else {
                    Wave.active = true
                    player.setItems(items, 0)
                    if (logged) {
                        val batch = Wave.batchId
                        launch(Dispatchers.IO) { yandex.waveFeedback("radioStarted", batch) }
                    } else {
                        toast("Без входа в Яндекс волна играет только SoundCloud")
                    }
                }
            } catch (e: Exception) {
                toast(e.message ?: "Не удалось запустить волну")
            } finally {
                waveLoading = false
            }
        }
    }

    fun isLiked(mediaId: String): Boolean = Taste.isLiked(mediaId)
    fun isDisliked(mediaId: String): Boolean = Taste.isDisliked(mediaId)

    /** Лайк: запоминаем исполнителя как любимого и ставим лайк в Яндексе. */
    fun toggleLike() {
        val item = player.currentItem() ?: return
        val id = item.mediaId
        val artist = item.mediaMetadata.artist?.toString().orEmpty()
        val now = !Taste.isLiked(id)
        Taste.setLiked(id, now)
        Taste.record(artist, if (now) 3 else -3)
        reactionVersion++
        if (now) {
            toast("Добавлено в любимое — волна учтёт")
            Eggs.countLike()
        }
        sendReaction(item, like = true, add = now)
    }

    /** Дизлайк: исполнитель уходит в минус, трек пропускается. */
    fun dislike() {
        val item = player.currentItem() ?: return
        val id = item.mediaId
        if (Taste.isDisliked(id)) {
            Taste.setDisliked(id, false)
            reactionVersion++
            sendReaction(item, like = false, add = false)
            return
        }
        Taste.setDisliked(id, true)
        Taste.record(item.mediaMetadata.artist?.toString().orEmpty(), -5)
        reactionVersion++
        sendReaction(item, like = false, add = true)
        if (Wave.active) {
            Wave.yandexId(item)?.let { yid ->
                val album = item.mediaMetadata.extras?.getString("albumId")
                val full = if (album != null) "$yid:$album" else yid
                val batch = Wave.batchId
                val played = player.position() / 1000.0
                scope.launch(Dispatchers.IO) { yandex.waveFeedback("skip", batch, full, played) }
            }
        }
        player.next()
        toast("Понял, такое реже")
    }

    private fun sendReaction(item: androidx.media3.common.MediaItem, like: Boolean, add: Boolean) {
        val yid = Wave.yandexId(item) ?: return
        if (!isLoggedIn) return
        val album = item.mediaMetadata.extras?.getString("albumId")
        scope.launch {
            try {
                withContext(Dispatchers.IO) { yandex.setReaction(yid, album, like, add) }
            } catch (e: Exception) {
                toast("Яндекс не принял оценку: ${e.message}")
            }
        }
    }

    companion object {
        lateinit var instance: PulseApp
            private set
    }
}
