package com.pulse.player.data

import android.content.Context
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

/** Плейлист, сохранённый в самом Lumo (например, импортированный из Spotify). */
data class LocalPlaylist(val id: String, val title: String, val origin: String, val tracks: List<Track>)

/** Импортированные плейлисты хранятся в файле на телефоне. */
object LocalLibrary {
    private lateinit var file: File

    fun init(context: Context) {
        file = File(context.filesDir, "playlists.json")
    }

    private fun Track.toJson() = JSONObject()
        .put("id", id).put("source", source.name).put("title", title).put("artist", artist)
        .put("cover", coverUrl ?: "").put("duration", durationMs).put("album", albumId ?: "")

    private fun trackFrom(o: JSONObject) = Track(
        id = o.optString("id"),
        source = if (o.optString("source") == "SOUNDCLOUD") Source.SOUNDCLOUD else Source.YANDEX,
        title = o.optString("title"),
        artist = o.optString("artist"),
        coverUrl = o.optString("cover").ifBlank { null },
        durationMs = o.optLong("duration"),
        albumId = o.optString("album").ifBlank { null },
    )

    @Synchronized
    fun load(): List<LocalPlaylist> = try {
        if (!file.exists()) emptyList() else {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val t = o.getJSONArray("tracks")
                LocalPlaylist(
                    o.optString("id"), o.optString("title"), o.optString("origin"),
                    (0 until t.length()).map { trackFrom(t.getJSONObject(it)) },
                )
            }
        }
    } catch (e: Exception) {
        emptyList()
    }

    @Synchronized
    fun save(list: List<LocalPlaylist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject().put("id", p.id).put("title", p.title).put("origin", p.origin)
                    .put("tracks", JSONArray().apply { p.tracks.forEach { put(it.toJson()) } })
            )
        }
        file.writeText(arr.toString())
    }
}

/**
 * Импорт плейлиста или альбома Spotify по ссылке — без входа в Spotify.
 * Читаем публичную встраиваемую страницу, берём «название + исполнитель».
 */
object SpotifyImport {
    data class Item(val title: String, val artist: String)

    private val linkRe = Regex("""spotify\.com/(?:intl-[a-z]+/)?(playlist|album)/([A-Za-z0-9]+)""")

    fun isLink(text: String) = linkRe.containsMatchIn(text)

    fun fetch(link: String): Pair<String, List<Item>> {
        val m = linkRe.find(link) ?: throw IOException("Это не ссылка на плейлист или альбом Spotify")
        val (type, id) = m.destructured
        val req = Request.Builder()
            .url("https://open.spotify.com/embed/$type/$id")
            .header("User-Agent", Http.UA)
            .header("Accept-Language", "ru,en")
            .build()
        val html = Http.client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("Spotify не отдал плейлист (${r.code}). Он открытый?")
            r.body?.string().orEmpty()
        }
        val json = Regex("""<script id="__NEXT_DATA__" type="application/json">(.*?)</script>""", RegexOption.DOT_MATCHES_ALL)
            .find(html)?.groupValues?.get(1)
            ?: throw IOException("Не получилось прочитать плейлист — Spotify мог поменять сайт")
        val entity = JSONObject(json).optJSONObject("props")?.optJSONObject("pageProps")
            ?.optJSONObject("state")?.optJSONObject("data")?.optJSONObject("entity")
            ?: throw IOException("Плейлист пустой или закрытый")
        val name = entity.optString("name").ifBlank { entity.optString("title") }.ifBlank { "Из Spotify" }
        val list = entity.optJSONArray("trackList") ?: JSONArray()
        val items = (0 until list.length()).mapNotNull { i ->
            val o = list.optJSONObject(i) ?: return@mapNotNull null
            val title = o.optString("title").replace(' ', ' ').trim()
            if (title.isEmpty()) null else Item(title, o.optString("subtitle").replace(' ', ' ').trim())
        }
        if (items.isEmpty()) throw IOException("В плейлисте не нашлось треков")
        return name to items
    }
}
