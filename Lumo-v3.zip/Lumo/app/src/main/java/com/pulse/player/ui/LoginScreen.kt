package com.pulse.player.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

enum class LoginService(val title: String, val startUrl: String, val hint: String) {
    YANDEX(
        "Вход в Яндекс",
        // client_id официального приложения Яндекс Музыки — после входа Яндекс отдаёт токен в адресе
        "https://oauth.yandex.ru/authorize?response_type=token&client_id=23cabbbdc6cd418abb4b39c32c41195d",
        "Пароль вводится на сайте Яндекса — Lumo его не видит",
    ),
    SOUNDCLOUD(
        "Вход в SoundCloud",
        "https://soundcloud.com/signin",
        "Входи по почте — вход через Google внутри приложений Google блокирует",
    ),
}

private val yaToken = Regex("access_token=([^&]+)")
private val scToken = Regex("oauth_token=([^;\\s]+)")

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginScreen(service: LoginService, onToken: (String) -> Unit, onClose: () -> Unit) {
    val tokenCallback by rememberUpdatedState(onToken)
    var manual by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .systemBarsPadding(),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Закрыть") }
            Text(service.title, style = MaterialTheme.typography.titleLarge)
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Lock, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            Text(service.hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    CookieManager.getInstance().setAcceptCookie(true)
                    webViewClient = object : WebViewClient() {
                        private var sent = false

                        private fun send(token: String?): Boolean {
                            if (token.isNullOrBlank() || sent) return false
                            sent = true
                            tokenCallback(token)
                            return true
                        }

                        private fun check(url: String?): Boolean = when (service) {
                            LoginService.YANDEX -> send(url?.let { yaToken.find(it)?.groupValues?.get(1) })
                            LoginService.SOUNDCLOUD -> {
                                val cookies = CookieManager.getInstance().getCookie("https://soundcloud.com").orEmpty()
                                send(scToken.find(cookies)?.groupValues?.get(1))
                            }
                        }

                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean =
                            service == LoginService.YANDEX && check(request?.url?.toString())

                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            if (check(url)) view?.stopLoading() else super.onPageStarted(view, url, favicon)
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            check(url)
                        }
                    }
                    loadUrl(service.startUrl)
                }
            },
        )

        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = manual,
                onValueChange = { manual = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("…или вставь токен вручную") },
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { if (manual.isNotBlank()) tokenCallback(manual.trim()) }) { Text("OK") }
        }
    }
}
