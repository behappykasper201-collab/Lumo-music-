package com.pulse.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.pulse.player.OpenedList
import com.pulse.player.PulseApp
import com.pulse.player.data.AppSettings

@Composable
fun LibraryScreen(app: PulseApp, settings: AppSettings) {
    val lib = app.library
    LaunchedEffect(app.tokens) { app.refreshLibrary() }

    val opened = lib.opened
    if (opened != null) {
        BackHandler { lib.opened = null }
        TrackListView(app, opened, settings)
        return
    }

    var importOpen by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Text("Медиатека", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }

        item {
            val importing = lib.importing
            LibraryRow(
                icon = Icons.Rounded.Link,
                title = "Импорт из Spotify",
                subtitle = importing ?: "Вставь ссылку на плейлист — найдём треки",
                loading = importing != null,
            ) { if (importing == null) importOpen = true }
        }

        if (app.tokens.yandex != null) {
            item { SectionTitle("Яндекс Музыка") }
            item {
                LibraryRow(Icons.Rounded.Favorite, "Мне нравится", "Твои лайки") { app.openYandexLikes() }
            }
            items(lib.yaPlaylists, key = { "ya" + it.kind }) { p ->
                LibraryRow(Icons.Rounded.QueueMusic, p.title, "${p.count} треков", cover = p.cover) { app.openYandexPlaylist(p) }
            }
        }

        if (app.tokens.soundcloud != null) {
            item { SectionTitle("SoundCloud") }
            item {
                LibraryRow(Icons.Rounded.Cloud, "Лайки", app.scName ?: "SoundCloud") { app.openSoundCloudLikes() }
            }
        }

        if (lib.local.isNotEmpty()) {
            item { SectionTitle("Мои плейлисты") }
            items(lib.local, key = { "local" + it.id }) { p ->
                LibraryRow(Icons.Rounded.QueueMusic, p.title, p.origin, cover = p.tracks.firstOrNull()?.coverUrl) { app.openLocal(p) }
            }
        }

        if (app.tokens.yandex == null && app.tokens.soundcloud == null) {
            item {
                Text(
                    "Подключи Яндекс или SoundCloud во вкладке «Вид → Аккаунты», и здесь появятся твои лайки и плейлисты.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }

    if (importOpen) {
        SpotifyImportDialog(
            onImport = { link ->
                importOpen = false
                app.importSpotify(link)
            },
            onClose = { importOpen = false },
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 10.dp),
    )
}

@Composable
private fun LibraryRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    cover: String? = null,
    loading: Boolean = false,
    onClick: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = panelColor(),
        border = panelBorder(),
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick),
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (cover != null) {
                Cover(cover, Modifier.size(52.dp), RoundedCornerShape(12.dp))
            } else {
                Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
                    if (loading) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                    }
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    subtitle, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun TrackListView(app: PulseApp, list: OpenedList, settings: AppSettings) {
    var confirmDelete by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { app.library.opened = null }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад")
            }
            Column(Modifier.weight(1f)) {
                Text(list.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(list.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (list.localId != null) {
                IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, "Удалить") }
            }
        }

        if (list.loading) {
            Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            TrackListBody(app, list, settings)
        }
    }

    if (confirmDelete && list.localId != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Удалить плейлист?") },
            text = { Text("«${list.title}» пропадёт из медиатеки. Треки в сервисах останутся.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    app.deleteLocal(list.localId)
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun TrackListBody(app: PulseApp, list: OpenedList, settings: AppSettings) {
    Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(onClick = { app.play(list.tracks, 0) }, enabled = list.tracks.isNotEmpty()) {
            Icon(Icons.Rounded.PlayArrow, null)
            Spacer(Modifier.width(6.dp))
            Text("Слушать")
        }
        FilledTonalButton(
            onClick = { app.play(list.tracks.shuffled(), 0) },
            enabled = list.tracks.isNotEmpty(),
        ) {
            Icon(Icons.Rounded.Shuffle, null)
            Spacer(Modifier.width(6.dp))
            Text("Вперемешку")
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)) {
        itemsIndexed(list.tracks, key = { i, t -> "${t.source}${t.id}#$i" }) { i, t ->
            TrackRow(t, settings.coverCorner.dp, app.preparingId == t.id) { app.play(list.tracks, i) }
        }
    }
}

@Composable
private fun SpotifyImportDialog(onImport: (String) -> Unit, onClose: () -> Unit) {
    var link by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Импорт из Spotify") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "В Spotify: плейлист → «Поделиться» → «Скопировать ссылку». Плейлист должен быть открытым. Вход в Spotify не нужен.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = link,
                    onValueChange = { link = it },
                    singleLine = true,
                    placeholder = { Text("https://open.spotify.com/playlist/…") },
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (link.isNotBlank()) onImport(link.trim()) }) { Text("Импорт") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Отмена") } },
    )
}
