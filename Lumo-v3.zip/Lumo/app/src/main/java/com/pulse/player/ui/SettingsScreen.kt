package com.pulse.player.ui

import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import com.pulse.player.PulseApp
import com.pulse.player.data.AppSettings
import com.pulse.player.data.BgStyle
import com.pulse.player.data.PlayerStyle
import com.pulse.player.data.ThemeMode
import com.pulse.player.data.Eggs
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableIntStateOf

private val presets = listOf(
    0xFF7C4DFF, 0xFF2979FF, 0xFF00B8D4, 0xFF00C853, 0xFFAEEA00, 0xFFFFD600,
    0xFFFF9100, 0xFFFF3D00, 0xFFFF1744, 0xFFF50057, 0xFFD500F9, 0xFFFFFFFF,
).map { it.toInt() }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(app: PulseApp, settings: AppSettings, onLogin: (LoginService) -> Unit) {
    fun save(f: (AppSettings) -> AppSettings) {
        app.scope.launch { app.settings.update(f) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Вид и настройки", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        // ---------- Аккаунты ----------
        Section("Аккаунты") {
            AccountRow(
                name = "Яндекс Музыка",
                status = when {
                    app.tokens.yandex == null -> "Не подключён"
                    app.accountName != null -> app.accountName!!
                    else -> "Подключён"
                },
                connected = app.tokens.yandex != null,
                onLogin = { onLogin(LoginService.YANDEX) },
                onLogout = app::logout,
            )
            AccountRow(
                name = "SoundCloud",
                status = when {
                    app.tokens.soundcloud == null -> "Не подключён · поиск работает и без входа"
                    app.scName != null -> app.scName!!
                    else -> "Подключён"
                },
                connected = app.tokens.soundcloud != null,
                onLogin = { onLogin(LoginService.SOUNDCLOUD) },
                onLogout = app::logoutSoundCloud,
            )
            AccountRow(
                name = "Spotify",
                status = "Без входа: импорт плейлистов по ссылке в «Медиатеке»",
                connected = false,
                onLogin = null,
                onLogout = {},
            )
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                Icon(Icons.Rounded.Lock, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    "Данные входа хранятся только на этом телефоне в зашифрованном виде и никуда не отправляются.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // ---------- Тема ----------
        Section("Тема") {
            val themes = ThemeMode.entries.filter { !it.hidden || (it == ThemeMode.RAINBOW && Eggs.isFound("tap_logo")) }
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                themes.forEach { m ->
                    ThemeTile(m, selected = settings.themeMode == m) { save { it.copy(themeMode = m) } }
                }
            }
            SwitchRow("Цвета по обложке", "Интерфейс перекрашивается под текущий трек", settings.coverColors) { v ->
                save { it.copy(coverColors = v) }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                SwitchRow("Material You", "Цвета из обоев телефона", settings.materialYou) { v ->
                    save { it.copy(materialYou = v) }
                }
            }
        }

        // ---------- Запуск ----------
        Section("Запуск") {
            SwitchRow("Приветствие", "«Доброе утро», случайные фразы и сюрпризы при запуске", settings.splash) { v ->
                save { it.copy(splash = v) }
            }
        }

        // ---------- Акцент ----------
        Section("Акцентный цвет") {
            var custom by remember { mutableStateOf(false) }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                presets.forEach { c ->
                    ColorDot(Color(c), selected = settings.accent == c) { save { it.copy(accent = c) } }
                }
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { custom = !custom },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Palette, "Свой цвет") }
            }
            if (custom) {
                Spacer(Modifier.height(8.dp))
                HsvPicker(settings.accent) { c -> save { it.copy(accent = c) } }
            }
            if (settings.themeMode == ThemeMode.MONO || settings.themeMode == ThemeMode.SMOKE || settings.themeMode.isPreset || settings.themeMode == ThemeMode.RAINBOW) {
                Text(
                    "У выбранной темы свои цвета — акцент и цвета по обложке работают в темах «Тёмная», «Светлая», «AMOLED» и «Как в системе».",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else if (settings.coverColors) {
                Text(
                    "Пока включены «Цвета по обложке», акцент используется только когда ничего не играет.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // ---------- Плеер ----------
        Section("Плеер") {
            Text("Стиль экрана плеера", style = MaterialTheme.typography.labelLarge)
            ChipRow(PlayerStyle.entries, settings.playerStyle, { it.label }) { s -> save { it.copy(playerStyle = s) } }
            Spacer(Modifier.height(6.dp))
            Text("Фон", style = MaterialTheme.typography.labelLarge)
            ChipRow(BgStyle.entries, settings.bgStyle, { it.label }) { s -> save { it.copy(bgStyle = s) } }
            if (settings.themeMode.autoBg) {
                Text(
                    "У выбранной темы свой фон — он подбирается автоматически.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(6.dp))

            var corner by remember(settings.coverCorner) { mutableFloatStateOf(settings.coverCorner.toFloat()) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Скругление обложки: ${corner.toInt()}", style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = corner, onValueChange = { corner = it }, valueRange = 0f..60f,
                        onValueChangeFinished = { val v = corner.toInt(); save { it.copy(coverCorner = v) } },
                    )
                }
                Spacer(Modifier.width(12.dp))
                Box(
                    Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape((corner * 56f / 300f).dp))
                        .background(MaterialTheme.colorScheme.primary)
                )
            }

            var speed by remember(settings.animSpeed) { mutableFloatStateOf(settings.animSpeed) }
            Text("Скорость анимаций: ×${"%.1f".format(speed)}", style = MaterialTheme.typography.labelLarge)
            Slider(
                value = speed, onValueChange = { speed = it }, valueRange = 0.2f..3f,
                onValueChangeFinished = { val v = speed; save { it.copy(animSpeed = v) } },
            )
        }

        var versionTaps by remember { mutableIntStateOf(0) }
        var showEggs by remember { mutableStateOf(false) }
        Text(
            "Lumo Music 0.1 · Яндекс Музыка через неофициальный API, SoundCloud через NewPipe Extractor",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null,
            ) {
                versionTaps++
                if (versionTaps >= 5) {
                    versionTaps = 0
                    Eggs.find("achievements", silent = true)
                    showEggs = true
                }
            },
        )
        if (showEggs) EggsDialog { showEggs = false }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ThemeTile(mode: ThemeMode, selected: Boolean, onClick: () -> Unit) {
    val bg = Color(mode.bg)
    val accent = if (mode == ThemeMode.MONO || mode == ThemeMode.SMOKE) Color.White else Color(mode.accent)
    val light = mode.isLightPreset || mode == ThemeMode.FROST || mode == ThemeMode.LIGHT
    Column(
        Modifier
            .width(76.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(bg)
                .border(
                    BorderStroke(
                        if (selected) 2.5.dp else 1.dp,
                        if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.15f),
                    ),
                    RoundedCornerShape(16.dp),
                ),
        ) {
            if (mode.isGlass) {
                Box(
                    Modifier.align(Alignment.Center).size(width = 44.dp, height = 18.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.White.copy(alpha = if (light) 0.6f else 0.18f))
                        .border(BorderStroke(0.8.dp, Color.White.copy(alpha = 0.4f)), RoundedCornerShape(6.dp))
                )
            }
            Box(
                Modifier.align(Alignment.BottomEnd).padding(8.dp).size(16.dp)
                    .clip(CircleShape).background(accent)
            )
            if (mode == ThemeMode.RAINBOW) {
                Text("🌈", modifier = Modifier.align(Alignment.TopStart).padding(6.dp))
            }
            if (selected) {
                Icon(
                    Icons.Rounded.Check, null,
                    tint = if (light) Color.Black else Color.White,
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(16.dp),
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            mode.label, style = MaterialTheme.typography.labelSmall, maxLines = 1,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun EggsDialog(onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Круто") } },
        title = { Text("Пасхалки: ${Eggs.foundCount()} из ${Eggs.all.size}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Eggs.all.forEach { e ->
                    val found = Eggs.isFound(e.id)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (found) "🥚" else "🔒", modifier = Modifier.width(28.dp))
                        Column {
                            Text(
                                if (found) e.title else "???",
                                style = MaterialTheme.typography.bodyLarge,
                            )
                            Text(
                                "Подсказка: ${e.hint}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        },
    )
}

@Composable
private fun AccountRow(name: String, status: String, connected: Boolean, onLogin: (() -> Unit)?, onLogout: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(10.dp).clip(CircleShape)
                .background(if (connected) Color(0xFF34C759) else MaterialTheme.colorScheme.outline)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, style = MaterialTheme.typography.bodyLarge)
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (onLogin != null) {
            Spacer(Modifier.width(8.dp))
            if (connected) {
                OutlinedButton(onClick = onLogout) { Text("Выйти") }
            } else {
                Button(onClick = onLogin) { Text("Войти") }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = panelColor(),
        border = panelBorder(),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun <T> ChipRow(items: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { item ->
            FilterChip(selected = item == selected, onClick = { onSelect(item) }, label = { Text(label(item)) })
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onChange(!checked) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(color)
            .border(BorderStroke(if (selected) 3.dp else 1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = if (selected) 0.9f else 0.2f)), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) Icon(Icons.Rounded.Check, null, tint = if (color == Color.White) Color.Black else Color.White)
    }
}

@Composable
private fun HsvPicker(initial: Int, onPick: (Int) -> Unit) {
    val hsv = remember(initial) { FloatArray(3).also { android.graphics.Color.colorToHSV(initial, it) } }
    var h by remember(initial) { mutableFloatStateOf(hsv[0]) }
    var s by remember(initial) { mutableFloatStateOf(hsv[1]) }
    var v by remember(initial) { mutableFloatStateOf(hsv[2]) }
    val current = Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))
    val commit = { onPick(current.toArgb()) }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(current))
        Spacer(Modifier.width(12.dp))
        Text("Свой цвет", style = MaterialTheme.typography.bodyLarge)
    }
    Text("Оттенок", style = MaterialTheme.typography.labelMedium)
    Slider(value = h, onValueChange = { h = it }, valueRange = 0f..360f, onValueChangeFinished = commit)
    Text("Насыщенность", style = MaterialTheme.typography.labelMedium)
    Slider(value = s, onValueChange = { s = it }, onValueChangeFinished = commit)
    Text("Яркость", style = MaterialTheme.typography.labelMedium)
    Slider(value = v, onValueChange = { v = it }, onValueChangeFinished = commit)
}
