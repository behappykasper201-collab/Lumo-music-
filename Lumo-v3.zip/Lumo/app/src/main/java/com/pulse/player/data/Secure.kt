package com.pulse.player.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Токены сервисов. Хранятся только на этом телефоне, в зашифрованном виде
 * (ключ лежит в защищённом хранилище Android — Keystore). На сервер не отправляются.
 */
object Secure {

    data class Tokens(val yandex: String? = null, val soundcloud: String? = null)

    private lateinit var prefs: SharedPreferences
    private val _state = MutableStateFlow(Tokens())
    val state: StateFlow<Tokens> = _state.asStateFlow()

    private fun open(context: Context): SharedPreferences {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedSharedPreferences.create(
            context,
            "secure_tokens",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    fun init(context: Context) {
        prefs = try {
            open(context)
        } catch (e: Exception) {
            // ключ повреждён (бывает после восстановления из бэкапа) — начинаем с чистого листа
            context.deleteSharedPreferences("secure_tokens")
            open(context)
        }
        _state.value = Tokens(prefs.getString("yandex", null), prefs.getString("soundcloud", null))
    }

    var yandex: String?
        get() = _state.value.yandex
        set(v) {
            prefs.edit().apply { if (v == null) remove("yandex") else putString("yandex", v) }.apply()
            _state.value = _state.value.copy(yandex = v)
        }

    var soundcloud: String?
        get() = _state.value.soundcloud
        set(v) {
            prefs.edit().apply { if (v == null) remove("soundcloud") else putString("soundcloud", v) }.apply()
            _state.value = _state.value.copy(soundcloud = v)
        }
}
