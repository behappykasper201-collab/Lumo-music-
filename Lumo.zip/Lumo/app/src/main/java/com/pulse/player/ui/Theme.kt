package com.pulse.player.ui

import android.app.Activity
import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.unit.dp
import com.pulse.player.data.BgStyle
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.pulse.player.data.AppSettings
import com.pulse.player.data.ThemeMode

private fun on(c: Color) = if (c.luminance() > 0.5f) Color(0xFF111114) else Color.White

/** Чёрно-белая палитра: почти чёрный фон, белые акценты, серые полутона. */
fun monoScheme(): ColorScheme {
    val bg = Color(0xFF090909)
    val surface = Color(0xFF111111)
    val variant = Color(0xFF1E1E1E)
    return darkColorScheme(
        primary = Color.White,
        onPrimary = bg,
        primaryContainer = Color(0xFF1C1C1C),
        onPrimaryContainer = Color.White,
        secondary = Color(0xFFBDBDBD),
        onSecondary = bg,
        secondaryContainer = Color(0xFF2A2A2A),
        onSecondaryContainer = Color.White,
        tertiary = Color(0xFF8A8A8A),
        onTertiary = bg,
        background = bg,
        onBackground = Color(0xFFF2F2F2),
        surface = surface,
        onSurface = Color(0xFFF2F2F2),
        surfaceVariant = variant,
        onSurfaceVariant = Color(0xFF9A9A9A),
        surfaceContainerLowest = bg,
        surfaceContainerLow = surface,
        surfaceContainer = surface,
        surfaceContainerHigh = Color(0xFF181818),
        surfaceContainerHighest = variant,
        outline = Color(0xFF4A4A4A),
        outlineVariant = Color(0xFF2A2A2A),
    )
}

/** Строит всю палитру приложения из одного «зерна»-цвета. */
fun schemeFromSeed(seed: Color, dark: Boolean, amoled: Boolean): ColorScheme {
    return if (dark) {
        val bg = if (amoled) Color.Black else lerp(Color(0xFF0D0D11), seed, 0.07f)
        val surface = if (amoled) Color(0xFF050505) else lerp(Color(0xFF15151B), seed, 0.09f)
        val variant = lerp(Color(0xFF24242D), seed, 0.16f)
        val primary = lerp(seed, Color.White, 0.12f)
        val secondaryContainer = lerp(surface, seed, 0.30f)
        darkColorScheme(
            primary = primary,
            onPrimary = on(primary),
            primaryContainer = lerp(seed, Color.Black, 0.45f),
            onPrimaryContainer = lerp(seed, Color.White, 0.85f),
            secondary = lerp(seed, Color.White, 0.35f),
            onSecondary = Color(0xFF111114),
            secondaryContainer = secondaryContainer,
            onSecondaryContainer = Color(0xFFF1F0F6),
            tertiary = lerp(seed, Color(0xFFFF6FB5), 0.45f),
            background = bg,
            onBackground = Color(0xFFEDEDF3),
            surface = surface,
            onSurface = Color(0xFFEDEDF3),
            surfaceVariant = variant,
            onSurfaceVariant = Color(0xFFB9B8C6),
            surfaceContainerLowest = bg,
            surfaceContainerLow = surface,
            surfaceContainer = surface,
            surfaceContainerHigh = lerp(surface, variant, 0.5f),
            surfaceContainerHighest = variant,
            outline = Color(0xFF6E6D7A),
            outlineVariant = Color(0xFF3A3944),
        )
    } else {
        val bg = lerp(Color(0xFFFAF9FD), seed, 0.05f)
        val surface = lerp(Color(0xFFF4F3F8), seed, 0.07f)
        val variant = lerp(Color(0xFFE4E2EC), seed, 0.14f)
        val primary = lerp(seed, Color.Black, 0.10f)
        lightColorScheme(
            primary = primary,
            onPrimary = on(primary),
            primaryContainer = lerp(seed, Color.White, 0.75f),
            onPrimaryContainer = lerp(seed, Color.Black, 0.65f),
            secondary = lerp(seed, Color.Black, 0.30f),
            onSecondary = Color.White,
            secondaryContainer = lerp(surface, seed, 0.25f),
            onSecondaryContainer = Color(0xFF1A1A22),
            tertiary = lerp(seed, Color(0xFFE0457B), 0.45f),
            background = bg,
            onBackground = Color(0xFF1A1A20),
            surface = surface,
            onSurface = Color(0xFF1A1A20),
            surfaceVariant = variant,
            onSurfaceVariant = Color(0xFF4A4955),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = bg,
            surfaceContainer = surface,
            surfaceContainerHigh = lerp(surface, variant, 0.5f),
            surfaceContainerHighest = variant,
            outline = Color(0xFF7A7986),
            outlineVariant = Color(0xFFC9C7D3),
        )
    }
}

/** Как выглядят панели: в стеклянных темах — полупрозрачный «лёд» с тонкой обводкой. */
data class GlassSpec(val enabled: Boolean = false, val tint: Color = Color.Unspecified, val border: Float = 0f)

val LocalGlass = staticCompositionLocalOf { GlassSpec() }

/** Цвет панели (карточки, мини-плеер, нижнее меню). */
@Composable
fun panelColor(): Color {
    val g = LocalGlass.current
    return if (g.enabled) g.tint else MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.88f)
}

/** Тонкая светлая обводка «стекла». */
@Composable
fun panelBorder(): BorderStroke? {
    val g = LocalGlass.current
    return if (g.enabled) BorderStroke(0.8.dp, Color.White.copy(alpha = g.border)) else null
}

/** Темы со своим фоном (стеклянные и готовые пресеты). */
fun effectiveBg(settings: AppSettings): BgStyle = when (settings.themeMode) {
    ThemeMode.GLASS -> BgStyle.BLUR
    ThemeMode.SMOKE, ThemeMode.MATRIX, ThemeMode.CRIMSON -> BgStyle.DOTS
    ThemeMode.FROST, ThemeMode.AURORA, ThemeMode.NEON, ThemeMode.OCEAN,
    ThemeMode.SAKURA, ThemeMode.FOREST, ThemeMode.RAINBOW -> BgStyle.ANIMATED
    ThemeMode.SUNSET, ThemeMode.COFFEE, ThemeMode.VAPOR, ThemeMode.DUNE -> BgStyle.GRADIENT
    else -> settings.bgStyle
}

/** Готовая тема: свой фон + свой акцент. */
fun presetScheme(bg: Color, accent: Color, light: Boolean): ColorScheme {
    val base = schemeFromSeed(accent, !light, false)
    val surface = if (light) lerp(bg, Color.White, 0.55f) else lerp(bg, Color.White, 0.05f)
    val variant = if (light) lerp(bg, Color.Black, 0.08f) else lerp(bg, Color.White, 0.11f)
    return base.copy(
        primary = accent,
        onPrimary = on(accent),
        background = bg,
        surface = surface,
        surfaceVariant = variant,
        surfaceContainerLowest = bg,
        surfaceContainerLow = surface,
        surfaceContainer = surface,
        surfaceContainerHigh = lerp(surface, variant, 0.5f),
        surfaceContainerHighest = variant,
        secondaryContainer = lerp(surface, accent, 0.25f),
        tertiary = lerp(accent, if (light) Color.Black else Color.White, 0.3f),
    )
}

@Composable
fun PulseTheme(settings: AppSettings, coverColor: Color?, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.FROST -> false
        else -> !settings.themeMode.isLightPreset
    }
    val amoled = settings.themeMode == ThemeMode.AMOLED
    val useCover = settings.coverColors && coverColor != null
    val target = if (useCover) coverColor!! else Color(settings.accent)
    val seed by animateColorAsState(target, tween(900), label = "seed")

    val context = LocalContext.current
    val mode = settings.themeMode
    val rainbowHue = if (mode == ThemeMode.RAINBOW) {
        val tr = rememberInfiniteTransition(label = "rainbow")
        val h by tr.animateFloat(0f, 360f, infiniteRepeatable(tween(12000, easing = LinearEasing)), label = "hue")
        h
    } else 0f
    val scheme = if (mode == ThemeMode.MONO || mode == ThemeMode.SMOKE) {
        monoScheme()
    } else if (mode.isPreset) {
        presetScheme(Color(mode.bg), Color(mode.accent), mode.isLightPreset)
    } else if (mode == ThemeMode.RAINBOW) {
        presetScheme(Color(mode.bg), Color.hsv(rainbowHue, 0.65f, 1f), false)
    } else if (settings.materialYou && !useCover && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val base = if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        if (amoled) base.copy(background = Color.Black, surface = Color(0xFF050505)) else base
    } else {
        schemeFromSeed(seed, dark, amoled)
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val ctrl = WindowCompat.getInsetsController(window, view)
            ctrl.isAppearanceLightStatusBars = !dark
            ctrl.isAppearanceLightNavigationBars = !dark
        }
    }

    val glass = when (settings.themeMode) {
        ThemeMode.GLASS -> GlassSpec(true, Color.White.copy(alpha = 0.12f), 0.22f)
        ThemeMode.SMOKE -> GlassSpec(true, Color.White.copy(alpha = 0.07f), 0.14f)
        ThemeMode.FROST -> GlassSpec(true, Color.White.copy(alpha = 0.55f), 0.75f)
        ThemeMode.AURORA -> GlassSpec(true, Color.Black.copy(alpha = 0.25f), 0.16f)
        else -> GlassSpec()
    }

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalGlass provides glass, content = content)
    }
}
