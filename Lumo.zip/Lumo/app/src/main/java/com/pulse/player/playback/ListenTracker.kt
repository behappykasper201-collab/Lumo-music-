package com.pulse.player.playback

import android.os.SystemClock
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import com.pulse.player.data.Eggs
import com.pulse.player.data.Taste
import com.pulse.player.data.YandexMusic
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Следит, дослушал ты трек или пропустил, и учит по этому вкус:
 * свой (Taste) и волну Яндекса (trackFinished / skip).
 */
class ListenTracker(
    private val player: Player,
    private val scope: CoroutineScope,
    private val api: YandexMusic,
) : Player.Listener {

    private var current: MediaItem? = null
    private var playedMs = 0L
    private var playingSince = -1L
    private var duration = 0L

    private fun now() = SystemClock.elapsedRealtime()

    override fun onIsPlayingChanged(isPlaying: Boolean) {
        if (isPlaying) {
            if (playingSince < 0) playingSince = now()
        } else if (playingSince >= 0) {
            playedMs += now() - playingSince
            playingSince = -1
        }
    }

    override fun onEvents(player: Player, events: Player.Events) {
        if (player.duration > 0) duration = player.duration
    }

    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
        finish(current, reason)
        current = mediaItem
        playedMs = 0
        duration = 0
        playingSince = if (player.isPlaying) now() else -1
    }

    private fun finish(item: MediaItem?, reason: Int) {
        if (item == null) return
        if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED ||
            reason == Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT
        ) return
        if (playingSince >= 0) playedMs += now() - playingSince

        val artist = item.mediaMetadata.artist?.toString().orEmpty()
        val finished = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO ||
            (duration > 0 && playedMs >= duration * 0.7)
        val skipped = !finished && playedMs < 30_000

        if (finished) {
            Eggs.countTrack()
            if (java.time.LocalTime.now().hour == 3) Eggs.find("night_owl")
        }
        when {
            finished -> Taste.record(artist, +1)
            skipped -> Taste.record(artist, -1)
        }

        // Волне Яндекса сообщаем, что было с треком
        val id = Wave.yandexId(item) ?: return
        if (!Wave.active || (!finished && !skipped)) return
        val album = item.mediaMetadata.extras?.getString("albumId")
        val full = if (album != null) "$id:$album" else id
        val batch = Wave.batchId
        val seconds = playedMs / 1000.0
        scope.launch(Dispatchers.IO) {
            api.waveFeedback(if (finished) "trackFinished" else "skip", batch, full, seconds)
        }
    }
}
