package com.pulse.player.ui

import android.net.Uri
import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.pulse.player.data.BgStyle
import com.pulse.player.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.sin

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun Cover(url: Any?, modifier: Modifier, shape: Shape) {
    Box(
        modifier.clip(shape).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            Icons.Rounded.MusicNote, null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxSize(0.4f),
        )
        if (url != null) {
            AsyncImage(
                model = url, contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

/** Главный цвет обложки — для подстройки темы под трек. */
@Composable
fun rememberCoverColor(uri: Uri?): Color? {
    val ctx = LocalContext.current
    val color by produceState<Color?>(null, uri) {
        if (uri == null) return@produceState
        val found: Color? = withContext(Dispatchers.IO) {
            try {
                val req = ImageRequest.Builder(ctx).data(uri).allowHardware(false).size(160).build()
                val bmp = (ctx.imageLoader.execute(req) as? SuccessResult)?.drawable?.toBitmap()
                if (bmp == null) {
                    null
                } else {
                    val p = Palette.from(bmp).generate()
                    val sw = p.vibrantSwatch ?: p.lightVibrantSwatch ?: p.dominantSwatch
                    sw?.rgb?.let { Color(it) }
                }
            } catch (e: Exception) {
                null
            }
        }
        if (found != null) value = found
    }
    return color
}

@Composable
fun TrackRow(track: Track, corner: Dp, loading: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(track.coverUrl, Modifier.size(52.dp), RoundedCornerShape(minOf(corner, 16.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
            Text(
                track.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.width(8.dp))
        if (loading) {
            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
        } else if (track.durationMs > 0) {
            Text(
                formatTime(track.durationMs), style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Фон приложения: однотонный, градиент, «живые» пятна или размытая обложка. */
@Composable
fun PulseBackground(style: BgStyle, artwork: Uri?, speed: Float, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Box(modifier.fillMaxSize().background(cs.background)) {
        when (style) {
            BgStyle.SOLID -> Unit
            BgStyle.DOTS -> HalftoneDots(
                if (cs.isMono()) cs.onBackground else cs.primary, speed, Modifier.fillMaxSize(),
                maxAlpha = if (cs.isMono()) 0.10f else 0.16f,
            )
            BgStyle.GRADIENT -> Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        listOf(cs.primary.copy(alpha = 0.40f), cs.tertiary.copy(alpha = 0.12f), Color.Transparent)
                    )
                )
            )
            BgStyle.ANIMATED -> AnimatedBlobs(
                listOf(cs.primary, cs.tertiary, cs.secondary), speed, Modifier.fillMaxSize(),
                alpha = if (cs.isMono()) 0.14f else 0.45f,
            )
            BgStyle.BLUR -> {
                if (artwork == null) {
                    AnimatedBlobs(listOf(cs.primary, cs.tertiary, cs.secondary), speed, Modifier.fillMaxSize(), alpha = 0.35f)
                } else {
                    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    AsyncImage(
                        model = artwork, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .then(if (canBlur) Modifier.blur(70.dp) else Modifier)
                            .alpha(if (canBlur) 0.65f else 0.30f),
                    )
                }
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(cs.background.copy(alpha = 0.25f), cs.background.copy(alpha = 0.85f)))
                    )
                )
            }
        }
    }
}

@Composable
fun AnimatedBlobs(colors: List<Color>, speed: Float, modifier: Modifier, alpha: Float = 0.45f) {
    val transition = rememberInfiniteTransition(label = "blobs")
    val duration = (16000 / speed.coerceIn(0.1f, 5f)).toInt()
    val t by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(duration, easing = LinearEasing), RepeatMode.Restart),
        label = "t",
    )
    Canvas(modifier) {
        val angle = t * 2f * Math.PI.toFloat()
        val r = size.minDimension * 0.75f
        colors.forEachIndexed { i, c ->
            val phase = angle + i * 2.1f
            val center = Offset(
                size.width * (0.5f + 0.35f * cos(phase * (1 + i * 0.3f))),
                size.height * (0.35f + 0.25f * sin(phase + i)),
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(c.copy(alpha = alpha), Color.Transparent), center, r),
                radius = r, center = center,
            )
        }
    }
}

/** Монохромная тема: основной цвет белый. */
fun androidx.compose.material3.ColorScheme.isMono(): Boolean =
    primary.red > 0.97f && primary.green > 0.97f && primary.blue > 0.97f

/**
 * Полутоновая сетка точек, по которой бегут волны — как на иконке Lumo.
 */
@Composable
fun HalftoneDots(color: Color, speed: Float, modifier: Modifier, maxAlpha: Float = 1f, spacing: Dp = 16.dp) {
    val transition = rememberInfiniteTransition(label = "dots")
    val duration = (9000 / speed.coerceIn(0.1f, 5f)).toInt()
    val t by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(duration, easing = LinearEasing), RepeatMode.Restart),
        label = "dt",
    )
    Canvas(modifier) {
        val step = spacing.toPx()
        val maxR = step * 0.42f
        val phase = t * 2f * Math.PI.toFloat()
        val cols = (size.width / step).toInt() + 1
        val rows = (size.height / step).toInt() + 1
        for (row in 0..rows) {
            for (col in 0..cols) {
                val x = col * step + step / 2
                val y = row * step + step / 2
                val wave = (sin(col * 0.35f + row * 0.18f - phase) + sin(row * 0.27f - col * 0.12f + phase * 0.6f)) / 4f + 0.5f
                val r = maxR * wave
                if (r > 0.4f) drawCircle(color.copy(alpha = maxAlpha * (0.35f + 0.65f * wave)), r, Offset(x, y))
            }
        }
    }
}
