package com.pulse.player.data

import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.security.MessageDigest
import java.time.Instant

/** Клиент неофициального API Яндекс Музыки (того же, что у их мобильного приложения). */
class YandexMusic(private val tokenProvider: () -> String?) {

    private val base = "https://api.music.yandex.net"

    @Volatile private var uid: String? = null

    private fun call(path: String, jsonBody: JSONObject? = null, form: Map<String, String>? = null): JSONObject {
        val b = Request.Builder()
            .url(base + path)
            .header("X-Yandex-Music-Client", "YandexMusicAndroid/24023621")
            .header("Accept-Language", "ru")
        tokenProvider()?.let { b.header("Authorization", "OAuth $it") }
        if (jsonBody != null) {
            b.post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
        } else if (form != null) {
            b.post(FormBody.Builder().apply { form.forEach { (k, v) -> add(k, v) } }.build())
        }
        Http.client.newCall(b.build()).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (r.code == 401 || r.code == 403) throw IOException("Яндекс: нужно войти в аккаунт")
            if (!r.isSuccessful) throw IOException("Яндекс: ошибка ${r.code}")
            return JSONObject(text)
        }
    }

    fun accountName(): String? {
        val acc = call("/account/status").optJSONObject("result")?.optJSONObject("account") ?: return null
        if (!acc.has("uid")) return null
        uid = acc.optString("uid")
        return acc.optString("displayName").ifBlank { acc.optString("login") }.ifBlank { "Аккаунт Яндекса" }
    }

    fun search(query: String): List<Track> {
        val q = URLEncoder.encode(query, "UTF-8")
        val res = call("/search?text=$q&type=track&page=0&nocorrect=false").optJSONObject("result")
        val arr = res?.optJSONObject("tracks")?.optJSONArray("results") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { parseTrack(arr.optJSONObject(it)) }
    }

    private fun parseTrack(o: JSONObject?): Track? {
        if (o == null) return null
        if (o.has("available") && !o.optBoolean("available")) return null
        val id = o.optString("id")
        if (id.isBlank()) return null
        val artists = o.optJSONArray("artists")
        val artist = if (artists == null) "" else (0 until artists.length())
            .joinToString(", ") { artists.optJSONObject(it)?.optString("name").orEmpty() }
        val cover = o.optString("coverUri").takeIf { it.isNotBlank() }
            ?.let { "https://" + it.replace("%%", "600x600") }
        val albumId = o.optJSONArray("albums")?.optJSONObject(0)?.optString("id")
        return Track(id, Source.YANDEX, o.optString("title"), artist, cover, o.optLong("durationMs"), albumId)
    }

    /** Получает прямую ссылку на mp3 (лучший битрейт). Ссылка живёт около минуты. */
    fun streamUrl(trackId: String): String {
        val arr = call("/tracks/$trackId/download-info").optJSONArray("result")
            ?: throw IOException("Яндекс: нет ссылки на трек")
        var best: JSONObject? = null
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("codec") != "mp3") continue
            val cur = best
            if (cur == null || o.optInt("bitrateInKbps") > cur.optInt("bitrateInKbps")) best = o
        }
        val chosen = best ?: throw IOException("Яндекс: трек недоступен")
        val req = Request.Builder().url(chosen.getString("downloadInfoUrl"))
            .apply { tokenProvider()?.let { header("Authorization", "OAuth $it") } }
            .build()
        val xml = Http.client.newCall(req).execute().use { it.body?.string().orEmpty() }
        fun tag(name: String): String =
            Regex("<$name>(.*?)</$name>").find(xml)?.groupValues?.get(1)
                ?: throw IOException("Яндекс: не удалось разобрать ответ")
        val host = tag("host")
        val path = tag("path")
        val ts = tag("ts")
        val s = tag("s")
        val sign = md5("XGRlBW9FXlekgbPrRHuSiA" + path.substring(1) + s)
        return "https://$host/get-mp3/$sign/$ts$path"
    }

    /** Следующая порция треков «Моей волны». */
    fun waveTracks(lastTrackId: String?): Pair<List<Track>, String?> {
        val q = if (lastTrackId != null) "&queue=$lastTrackId" else ""
        val res = call("/rotor/station/user:onyourwave/tracks?settings2=true$q").optJSONObject("result")
            ?: return emptyList<Track>() to null
        val seq = res.optJSONArray("sequence")
        val list = if (seq == null) emptyList() else (0 until seq.length())
            .mapNotNull { parseTrack(seq.optJSONObject(it)?.optJSONObject("track")) }
        return list to res.optString("batchId").ifBlank { null }
    }

    /** Сообщаем волне, что слушаем, — так рекомендации подстраиваются. Ошибки не важны. */
    fun waveFeedback(type: String, batchId: String?, trackId: String? = null, playedSeconds: Double? = null) {
        runCatching {
            val body = JSONObject()
                .put("type", type)
                .put("timestamp", Instant.now().toString())
                .put("from", "mobile-radio-user-onyourwave")
            if (trackId != null) body.put("trackId", trackId)
            if (playedSeconds != null) body.put("totalPlayedSeconds", playedSeconds)
            val q = if (batchId != null) "?batch-id=$batchId" else ""
            call("/rotor/station/user:onyourwave/feedback$q", body)
        }
    }

    /** Настройки волны: настроение, характер, язык — как в приложении Яндекса. */
    fun setWaveSettings(mood: String, diversity: String, language: String) {
        runCatching {
            call(
                "/rotor/station/user:onyourwave/settings2",
                JSONObject().put("moodEnergy", mood).put("diversity", diversity).put("language", language),
            )
        }
    }

    private fun ensureUid(): String {
        uid?.let { return it }
        accountName()
        return uid ?: throw IOException("Яндекс: нужно войти в аккаунт")
    }

    /** Лайк / дизлайк трека в аккаунте Яндекса. */
    fun setReaction(trackId: String, albumId: String?, like: Boolean, add: Boolean) {
        val u = ensureUid()
        val ids = if (albumId != null) "$trackId:$albumId" else trackId
        val kind = if (like) "likes" else "dislikes"
        val action = if (add) "add-multiple" else "remove"
        call("/users/$u/$kind/tracks/$action", form = mapOf("track-ids" to ids))
    }

    private fun md5(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
