package com.pulse.player.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode(val label: String, val bg: Long, val accent: Long, val hidden: Boolean = false) {
    MONO("Монохром", 0xFF090909, 0xFFFFFFFF),
    GLASS("Стекло", 0xFF2B1B3D, 0xFFE9A0C0),
    SMOKE("Дымка", 0xFF090909, 0xFF9A9A9A),
    FROST("Иней", 0xFFEEF0F7, 0xFF8E7CFF),
    AURORA("Аврора", 0xFF07121A, 0xFF00C2A8),
    NEON("Неон", 0xFF05040A, 0xFF00F0FF),
    MATRIX("Матрица", 0xFF020803, 0xFF00FF66),
    SUNSET("Закат", 0xFF1A0E1F, 0xFFFF8A3D),
    OCEAN("Океан", 0xFF041420, 0xFF2EC4B6),
    SAKURA("Сакура", 0xFFFFF1F5, 0xFFE0577E),
    COFFEE("Кофе", 0xFF1A120D, 0xFFD9A066),
    FOREST("Лес", 0xFF0A140D, 0xFF7CC47F),
    VAPOR("Вейпорвейв", 0xFF1B0B2E, 0xFFFF71CE),
    CRIMSON("Багровый", 0xFF0B0505, 0xFFE53935),
    DUNE("Дюна", 0xFFF4EBDD, 0xFFC0643A),
    SYSTEM("Как в системе", 0xFF1E1E24, 0xFF7C4DFF),
    LIGHT("Светлая", 0xFFF7F6FB, 0xFF7C4DFF),
    DARK("Тёмная", 0xFF0E0E12, 0xFF7C4DFF),
    AMOLED("AMOLED", 0xFF000000, 0xFF7C4DFF),
    RAINBOW("Радуга", 0xFF0A0A0F, 0xFFFF4FA3, hidden = true);

    val isGlass get() = this == GLASS || this == SMOKE || this == FROST || this == AURORA
    val isPreset get() = ordinal in NEON.ordinal..DUNE.ordinal
    val isLightPreset get() = this == SAKURA || this == DUNE
    /** Темы со своим фоном — выбор фона в настройках не действует. */
    val autoBg get() = isGlass || isPreset || this == RAINBOW
}

enum class PlayerStyle(val label: String) { CLASSIC("Классика"), BIG("Большая обложка"), VINYL("Винил"), MINIMAL("Минимал") }
enum class BgStyle(val label: String) { SOLID("Однотонный"), DOTS("Точки"), GRADIENT("Градиент"), ANIMATED("Живой"), BLUR("Размытая обложка") }

enum class WaveMood(val label: String, val api: String) {
    ALL("Любое", "all"), ACTIVE("Бодрое", "active"), FUN("Весёлое", "fun"), CALM("Спокойное", "calm"), SAD("Грустное", "sad")
}
enum class WaveDiversity(val label: String, val api: String) {
    DEFAULT("Как обычно", "default"), FAVORITE("Любимое", "favorite"), DISCOVER("Незнакомое", "discover"), POPULAR("Популярное", "popular")
}
enum class WaveLanguage(val label: String, val api: String) {
    ANY("Любой", "any"), RUSSIAN("Русский", "russian"), FOREIGN("Иностранный", "not-russian"), NO_WORDS("Без слов", "without-words")
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.MONO,
    val accent: Int = 0xFF7C4DFF.toInt(),
    val coverColors: Boolean = true,
    val materialYou: Boolean = false,
    val playerStyle: PlayerStyle = PlayerStyle.CLASSIC,
    val bgStyle: BgStyle = BgStyle.DOTS,
    val coverCorner: Int = 20,
    val animSpeed: Float = 1f,
    val yandexToken: String? = null,
    val waveMood: WaveMood = WaveMood.ALL,
    val waveDiversity: WaveDiversity = WaveDiversity.DEFAULT,
    val waveLanguage: WaveLanguage = WaveLanguage.ANY,
    val scShare: Float = 0.35f,
    val splash: Boolean = true,
)

private val Context.dataStore by preferencesDataStore("settings")

class SettingsStore(private val context: Context) {

    private object K {
        val theme = stringPreferencesKey("theme")
        val accent = intPreferencesKey("accent")
        val coverColors = booleanPreferencesKey("cover_colors")
        val materialYou = booleanPreferencesKey("material_you")
        val playerStyle = stringPreferencesKey("player_style")
        val bgStyle = stringPreferencesKey("bg_style")
        val coverCorner = intPreferencesKey("cover_corner")
        val animSpeed = floatPreferencesKey("anim_speed")
        val token = stringPreferencesKey("yandex_token")
        val waveMood = stringPreferencesKey("wave_mood")
        val waveDiversity = stringPreferencesKey("wave_diversity")
        val waveLanguage = stringPreferencesKey("wave_language")
        val scShare = floatPreferencesKey("sc_share")
        val splash = booleanPreferencesKey("splash")
    }

    val flow: Flow<AppSettings> = context.dataStore.data.map { read(it) }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { p -> write(p, transform(read(p))) }
    }

    private inline fun <reified E : Enum<E>> enumOf(value: String?, default: E): E =
        value?.let { v -> enumValues<E>().firstOrNull { it.name == v } } ?: default

    private fun read(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            themeMode = enumOf(p[K.theme], d.themeMode),
            accent = p[K.accent] ?: d.accent,
            coverColors = p[K.coverColors] ?: d.coverColors,
            materialYou = p[K.materialYou] ?: d.materialYou,
            playerStyle = enumOf(p[K.playerStyle], d.playerStyle),
            bgStyle = enumOf(p[K.bgStyle], d.bgStyle),
            coverCorner = p[K.coverCorner] ?: d.coverCorner,
            animSpeed = p[K.animSpeed] ?: d.animSpeed,
            yandexToken = p[K.token],
            waveMood = enumOf(p[K.waveMood], d.waveMood),
            waveDiversity = enumOf(p[K.waveDiversity], d.waveDiversity),
            waveLanguage = enumOf(p[K.waveLanguage], d.waveLanguage),
            scShare = p[K.scShare] ?: d.scShare,
            splash = p[K.splash] ?: d.splash,
        )
    }

    private fun write(p: MutablePreferences, s: AppSettings) {
        p[K.theme] = s.themeMode.name
        p[K.accent] = s.accent
        p[K.coverColors] = s.coverColors
        p[K.materialYou] = s.materialYou
        p[K.playerStyle] = s.playerStyle.name
        p[K.bgStyle] = s.bgStyle.name
        p[K.coverCorner] = s.coverCorner
        p[K.animSpeed] = s.animSpeed
        p[K.waveMood] = s.waveMood.name
        p[K.waveDiversity] = s.waveDiversity.name
        p[K.waveLanguage] = s.waveLanguage.name
        p[K.scShare] = s.scShare
        p[K.splash] = s.splash
        if (s.yandexToken != null) p[K.token] = s.yandexToken else p.remove(K.token)
    }
}
