package com.pulse.player.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pulse.player.data.Greeting
import kotlinx.coroutines.delay

/** Экран при запуске: приветствие печатается по буквам, ниже — случайная фраза. Тап — пропустить. */
@Composable
fun SplashScreen(greeting: Greeting, onDone: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val done by rememberUpdatedState(onDone)
    var typed by remember { mutableIntStateOf(0) }
    var showSub by remember { mutableStateOf(false) }

    LaunchedEffect(greeting) {
        delay(250)
        while (typed < greeting.title.length) {
            typed++
            delay(55)
        }
        delay(150)
        showSub = true
        delay(1800)
        done()
    }

    val cursor by rememberInfiniteTransition(label = "cursor").animateFloat(
        1f, 0f, infiniteRepeatable(tween(480), RepeatMode.Reverse), label = "blink",
    )
    val subAlpha by animateFloatAsState(if (showSub) 1f else 0f, tween(700), label = "sub")

    Box(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { done() },
    ) {
        HalftoneDots(
            if (cs.isMono()) cs.onBackground else cs.primary, 1.3f, Modifier.fillMaxSize(),
            maxAlpha = 0.14f,
        )
        Column(
            Modifier.align(Alignment.Center).padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    greeting.title.take(typed),
                    modifier = Modifier.weight(1f, fill = false),
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold,
                    color = cs.onBackground,
                    textAlign = TextAlign.Center,
                )
                Box(
                    Modifier
                        .padding(start = 6.dp)
                        .size(width = 4.dp, height = 38.dp)
                        .background(cs.primary.copy(alpha = cursor))
                )
            }
            Spacer(Modifier.height(16.dp))
            Text(
                greeting.subtitle,
                modifier = Modifier.alpha(subAlpha),
                style = MaterialTheme.typography.titleMedium,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
        Text(
            "l u m o",
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 56.dp).alpha(0.45f),
            style = MaterialTheme.typography.labelLarge,
            letterSpacing = 4.sp,
            color = cs.onBackground,
        )
    }
}
