package com.pulse.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pulse.player.PulseApp
import com.pulse.player.data.AppSettings
import com.pulse.player.data.WaveDiversity
import com.pulse.player.data.WaveLanguage
import com.pulse.player.data.WaveMood
import java.time.LocalTime
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.mutableIntStateOf
import com.pulse.player.data.Eggs
import com.pulse.player.data.Phrases
import kotlin.math.roundToInt
import kotlinx.coroutines.launch
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Slider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(app: PulseApp, settings: AppSettings) {
    val hour = LocalTime.now().hour
    val greeting = Phrases.title(hour)
    val phrase = remember { Phrases.subtitle(hour) }
    var logoTaps by remember { mutableIntStateOf(0) }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column {
            Text(
                "Lumo",
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Black,
                modifier = Modifier.clickable(
                    interactionSource = remember { MutableInteractionSource() }, indication = null,
                ) {
                    logoTaps++
                    when (logoTaps) {
                        3 -> app.toast("Ещё чуть-чуть…")
                        5 -> app.toast("Почти…")
                        7 -> if (Eggs.find("tap_logo")) {
                            app.toast("🌈 Открыта секретная тема «Радуга» — она в настройках")
                        } else {
                            app.toast("Радуга уже твоя 🌈")
                        }
                        20 -> app.toast("Логотип устал. Дай ему отдохнуть 😮‍💨")
                    }
                },
            )
            Text(
                app.accountName?.let { "$greeting, $it" } ?: greeting,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                phrase,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            )
        }

        WaveCard(
            loading = app.waveLoading, speed = settings.animSpeed, onClick = app::startWave,
            onLongClick = {
                Eggs.find("long_press_wave")
                app.toast(Phrases.secrets.random())
            },
        )
        WaveSettingsCard(app, settings)

        if (app.accountName == null) {
            InfoCard(Icons.Rounded.Info, "Войди в Яндекс Музыку во вкладке «Вид», чтобы в волне был твой Яндекс. Без входа волна играет только SoundCloud.")
        }
        InfoCard(Icons.Rounded.Cloud, "SoundCloud работает без входа — переключись на него во вкладке «Поиск».")
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun WaveCard(loading: Boolean, speed: Float, onClick: () -> Unit, onLongClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .fillMaxWidth()
            .height(220.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(Brush.linearGradient(listOf(cs.primaryContainer, cs.surfaceContainerHigh)))
            .combinedClickable(enabled = !loading, onClick = onClick, onLongClick = onLongClick),
    ) {
        if (cs.isMono()) {
            HalftoneDots(Color.White, speed * 1.4f, Modifier.fillMaxSize(), maxAlpha = 0.55f, spacing = 14.dp)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f)))))
        } else {
            AnimatedBlobs(listOf(cs.primary, cs.tertiary, cs.secondary), speed * 1.6f, Modifier.fillMaxSize(), alpha = 0.7f)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f)))))
        }
        Column(Modifier.align(Alignment.BottomStart).padding(24.dp)) {
            Text("Моя волна", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Яндекс + SoundCloud вперемешку", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.85f))
        }
        Surface(
            shape = CircleShape,
            color = Color.White,
            modifier = Modifier.align(Alignment.TopEnd).padding(20.dp).size(60.dp),
        ) {
            Box(contentAlignment = Alignment.Center) {
                if (loading) {
                    CircularProgressIndicator(Modifier.size(26.dp), color = Color.Black, strokeWidth = 3.dp)
                } else {
                    Icon(Icons.Rounded.PlayArrow, "Запустить", tint = Color.Black, modifier = Modifier.size(34.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun WaveSettingsCard(app: PulseApp, settings: AppSettings) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    fun save(f: (AppSettings) -> AppSettings) {
        app.scope.launch { app.settings.update(f) }
    }

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = panelColor(),
        border = panelBorder(),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.animateContentSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Tune, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.size(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Настроить волну", style = MaterialTheme.typography.titleMedium)
                    Text(
                        listOf(settings.waveMood.label, settings.waveDiversity.label, settings.waveLanguage.label)
                            .joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Icon(if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null)
            }
            if (expanded) {
                WaveChips("Настроение", WaveMood.entries, settings.waveMood, { it.label }) { v -> save { it.copy(waveMood = v) } }
                WaveChips("Характер", WaveDiversity.entries, settings.waveDiversity, { it.label }) { v -> save { it.copy(waveDiversity = v) } }
                WaveChips("Язык", WaveLanguage.entries, settings.waveLanguage, { it.label }) { v -> save { it.copy(waveLanguage = v) } }

                var share by remember(settings.scShare) { mutableFloatStateOf(settings.scShare) }
                Text(
                    "SoundCloud в волне: ${(share * 100).roundToInt()}%",
                    style = MaterialTheme.typography.labelLarge,
                )
                Slider(
                    value = share, onValueChange = { share = it }, steps = 9,
                    onValueChangeFinished = { val v = share; save { it.copy(scShare = v) } },
                )
                Text(
                    "Волна учится сама: дослушал — это нравится, быстро пропустил — не очень. " +
                        "Сердечко и 👎 в плеере работают сильнее.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun <T> WaveChips(title: String, items: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Text(title, style = MaterialTheme.typography.labelLarge)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { item ->
            FilterChip(selected = item == selected, onClick = { onSelect(item) }, label = { Text(label(item)) })
        }
    }
}

@Composable
private fun InfoCard(icon: ImageVector, text: String) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = panelColor(),
        border = panelBorder(),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.size(12.dp))
            Text(text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
