package com.pulse.player.data

import android.net.Uri
import android.os.Bundle
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

enum class Source { YANDEX, SOUNDCLOUD }

data class Track(
    val id: String,
    val source: Source,
    val title: String,
    val artist: String,
    val coverUrl: String?,
    val durationMs: Long,
    val albumId: String? = null,
)

object Http {
    const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
}

/**
 * Яндекс-треки получают адрес вида ym://<id> — настоящая ссылка на mp3
 * запрашивается прямо перед загрузкой (она живёт недолго).
 * SoundCloud-треки приходят уже с готовой ссылкой.
 */
fun Track.toMediaItem(streamUrl: String? = null, hls: Boolean = false): MediaItem {
    val uri = when (source) {
        Source.YANDEX -> "ym://$id"
        Source.SOUNDCLOUD -> streamUrl ?: ""
    }
    val extras = Bundle().apply {
        putBoolean("hls", hls)
        putString("albumId", albumId)
    }
    val meta = MediaMetadata.Builder()
        .setTitle(title)
        .setArtist(artist)
        .setArtworkUri(coverUrl?.let { Uri.parse(it) })
        .setExtras(extras)
        .build()
    val builder = MediaItem.Builder()
        .setMediaId("${source.name}|$id")
        .setUri(uri)
        .setMediaMetadata(meta)
        .setRequestMetadata(
            MediaItem.RequestMetadata.Builder()
                .setMediaUri(Uri.parse(uri))
                .setExtras(extras)
                .build()
        )
    if (hls) builder.setMimeType(MimeTypes.APPLICATION_M3U8)
    return builder.build()
}

/** При передаче через MediaController адрес может потеряться — восстанавливаем его. */
fun MediaItem.restoreLocal(): MediaItem {
    if (localConfiguration != null) return this
    val uri = requestMetadata.mediaUri ?: return this
    val builder = buildUpon().setUri(uri)
    if (requestMetadata.extras?.getBoolean("hls") == true) builder.setMimeType(MimeTypes.APPLICATION_M3U8)
    return builder.build()
}
