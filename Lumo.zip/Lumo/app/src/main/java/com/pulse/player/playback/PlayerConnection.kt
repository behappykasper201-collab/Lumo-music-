package com.pulse.player.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.pulse.player.PulseApp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PlayerUi(
    val hasItem: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val artwork: Uri? = null,
    val isPlaying: Boolean = false,
    val buffering: Boolean = false,
    val duration: Long = 0,
    val source: String = "",
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val shuffle: Boolean = false,
    val mediaId: String = "",
)

/** Связь интерфейса с сервисом воспроизведения. */
class PlayerConnection(context: Context) {

    private var controller: MediaController? = null
    private val pending = mutableListOf<(MediaController) -> Unit>()

    private val _state = MutableStateFlow(PlayerUi())
    val state: StateFlow<PlayerUi> = _state.asStateFlow()

    init {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) = update()
                override fun onPlayerError(error: PlaybackException) {
                    val reason = error.cause?.message ?: error.errorCodeName
                    PulseApp.instance.toast("Не получилось воспроизвести: $reason")
                }
            })
            update()
            pending.forEach { it(c) }
            pending.clear()
        }, ContextCompat.getMainExecutor(context))
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else pending.add(block)
    }

    private fun update() {
        val c = controller ?: return
        val m = c.mediaMetadata
        val item = c.currentMediaItem
        _state.value = PlayerUi(
            hasItem = item != null,
            title = m.title?.toString().orEmpty(),
            artist = m.artist?.toString().orEmpty(),
            artwork = m.artworkUri,
            isPlaying = c.isPlaying,
            buffering = c.playbackState == Player.STATE_BUFFERING,
            duration = c.duration.coerceAtLeast(0),
            source = item?.mediaId?.substringBefore("|").orEmpty(),
            repeat = c.repeatMode,
            shuffle = c.shuffleModeEnabled,
            mediaId = item?.mediaId.orEmpty(),
        )
    }

    fun currentItem(): MediaItem? = controller?.currentMediaItem

    fun position(): Long = controller?.currentPosition ?: 0L

    fun setItems(items: List<MediaItem>, index: Int) = withController {
        it.setMediaItems(items, index, 0)
        it.prepare()
        it.play()
    }

    fun addItems(items: List<MediaItem>) = withController { it.addMediaItems(items) }

    fun toggle() = withController {
        if (it.isPlaying) {
            it.pause()
        } else {
            if (it.playbackState == Player.STATE_IDLE) it.prepare()
            it.play()
        }
    }

    fun next() = withController { it.seekToNext() }
    fun previous() = withController { it.seekToPrevious() }
    fun seek(ms: Long) = withController { it.seekTo(ms) }

    fun cycleRepeat() = withController {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun toggleShuffle() = withController { it.shuffleModeEnabled = !it.shuffleModeEnabled }
}
