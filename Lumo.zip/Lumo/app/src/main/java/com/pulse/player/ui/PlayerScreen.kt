package com.pulse.player.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.ThumbDown
import androidx.compose.material.icons.rounded.ThumbDownOffAlt
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import com.pulse.player.PulseApp
import com.pulse.player.data.AppSettings
import com.pulse.player.data.PlayerStyle
import com.pulse.player.playback.PlayerUi
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.rememberCoroutineScope
import com.pulse.player.data.Eggs

@Composable
fun PlayerScreen(app: PulseApp, ps: PlayerUi, settings: AppSettings, onClose: () -> Unit) {
    val player = app.player
    val position by produceState(0L) {
        while (true) {
            value = player.position()
            delay(400)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            // перехватываем касания, чтобы они не уходили на экран под плеером
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
    ) {
        PulseBackground(effectiveBg(settings), ps.artwork, settings.animSpeed)

        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Rounded.KeyboardArrowDown, "Свернуть", Modifier.size(32.dp))
                }
                Text(
                    when (ps.source) {
                        "YANDEX" -> "Яндекс Музыка"
                        "SOUNDCLOUD" -> "SoundCloud"
                        else -> ""
                    },
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.size(48.dp))
            }

            Spacer(Modifier.weight(1f))
            PlayerCover(ps, settings)
            Spacer(Modifier.weight(1f))

            val big = settings.playerStyle == PlayerStyle.MINIMAL
            @Suppress("UNUSED_VARIABLE") val v = app.reactionVersion // перерисовка после лайка
            val liked = app.isLiked(ps.mediaId)
            val disliked = app.isDisliked(ps.mediaId)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = app::dislike) {
                    Icon(
                        if (disliked) Icons.Rounded.ThumbDown else Icons.Rounded.ThumbDownOffAlt, "Не нравится",
                        tint = if (disliked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Column(
                    Modifier.weight(1f).padding(horizontal = 4.dp),
                    horizontalAlignment = if (big) Alignment.Start else Alignment.CenterHorizontally,
                ) {
                    Text(
                        ps.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        style = if (big) MaterialTheme.typography.displaySmall else MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        textAlign = if (big) TextAlign.Start else TextAlign.Center,
                    )
                    Text(
                        ps.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                val heartScale by animateFloatAsState(
                    if (liked) 1.2f else 1f, spring(dampingRatio = 0.35f), label = "heart",
                )
                IconButton(onClick = app::toggleLike) {
                    Icon(
                        if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Нравится",
                        tint = if (liked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.graphicsLayer { scaleX = heartScale; scaleY = heartScale },
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            SeekBar(position, ps.duration) { player.seek(it) }
            Spacer(Modifier.height(8.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = player::toggleShuffle) {
                    Icon(
                        Icons.Rounded.Shuffle, "Перемешать",
                        tint = if (ps.shuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = player::previous, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, "Назад", Modifier.size(38.dp))
                }
                FilledIconButton(onClick = player::toggle, modifier = Modifier.size(80.dp), shape = CircleShape) {
                    if (ps.buffering && !ps.isPlaying) {
                        CircularProgressIndicator(Modifier.size(30.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 3.dp)
                    } else {
                        Icon(
                            if (ps.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            "Играть", Modifier.size(44.dp),
                        )
                    }
                }
                IconButton(onClick = player::next, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipNext, "Дальше", Modifier.size(38.dp))
                }
                IconButton(onClick = player::cycleRepeat) {
                    Icon(
                        if (ps.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        "Повтор",
                        tint = if (ps.repeat != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun PlayerCover(ps: PlayerUi, settings: AppSettings) {
    val scale by animateFloatAsState(
        if (ps.isPlaying) 1f else 0.88f,
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow),
        label = "coverScale",
    )
    val shape = RoundedCornerShape(settings.coverCorner.dp)
    val grow = Modifier.graphicsLayer { scaleX = scale; scaleY = scale }

    when (settings.playerStyle) {
        PlayerStyle.CLASSIC -> Cover(
            ps.artwork,
            Modifier.fillMaxWidth(0.88f).aspectRatio(1f).then(grow).shadow(28.dp, shape),
            shape,
        )
        PlayerStyle.BIG -> Cover(
            ps.artwork,
            Modifier.fillMaxWidth().aspectRatio(0.9f).then(grow).shadow(36.dp, shape),
            shape,
        )
        PlayerStyle.MINIMAL -> Box(Modifier.fillMaxWidth()) {
            Cover(ps.artwork, Modifier.fillMaxWidth(0.55f).aspectRatio(1f).then(grow), shape)
        }
        PlayerStyle.VINYL -> Vinyl(ps, settings.animSpeed, grow)
    }
}

@Composable
private fun Vinyl(ps: PlayerUi, speed: Float, grow: Modifier) {
    val rotation = remember { Animatable(0f) }
    LaunchedEffect(ps.isPlaying, speed) {
        if (ps.isPlaying) {
            val turn = (6000 / speed.coerceIn(0.2f, 5f)).toInt()
            while (isActive) {
                val start = rotation.value % 360f
                rotation.snapTo(start)
                rotation.animateTo(start + 360f, tween(turn, easing = LinearEasing))
            }
        }
    }
    val groove = MaterialTheme.colorScheme.primary
    val scope = rememberCoroutineScope()
    var taps by remember { mutableIntStateOf(0) }
    var lastTap by remember { mutableLongStateOf(0L) }
    Box(
        Modifier
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                val now = System.currentTimeMillis()
                taps = if (now - lastTap < 1200) taps + 1 else 1
                lastTap = now
                if (taps >= 10) {
                    taps = 0
                    Eggs.find("vinyl_scratch")
                    PulseApp.instance.toast("Вжжжик! 🎛️ DJ-режим")
                    scope.launch {
                        val v = rotation.value
                        rotation.animateTo(v - 540f, tween(350))
                        rotation.animateTo(v + 180f, tween(500))
                    }
                }
            }
            .fillMaxWidth(0.86f)
            .aspectRatio(1f)
            .then(grow)
            .shadow(30.dp, CircleShape)
            .clip(CircleShape)
            .background(Color(0xFF0B0B0D))
            .graphicsLayer { rotationZ = rotation.value },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, size.height / 2)
            var r = size.minDimension / 2 * 0.95f
            while (r > size.minDimension * 0.33f) {
                drawCircle(Color.White.copy(alpha = 0.05f), r, c, style = Stroke(1.2f))
                r -= size.minDimension * 0.018f
            }
            drawCircle(groove.copy(alpha = 0.25f), size.minDimension * 0.47f, c, style = Stroke(3f))
        }
        Cover(ps.artwork, Modifier.fillMaxWidth(0.6f).aspectRatio(1f), CircleShape)
        Box(Modifier.size(14.dp).clip(CircleShape).background(Color(0xFF0B0B0D)))
    }
}

@Composable
private fun SeekBar(position: Long, duration: Long, onSeek: (Long) -> Unit) {
    var dragging by remember { mutableStateOf<Float?>(null) }
    val fraction = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
    Column(Modifier.fillMaxWidth()) {
        Slider(
            value = dragging ?: fraction,
            onValueChange = { dragging = it },
            onValueChangeFinished = {
                dragging?.let { onSeek((it * duration).toLong()) }
                dragging = null
            },
            enabled = duration > 0,
        )
        Row(Modifier.fillMaxWidth()) {
            val shown = dragging?.let { (it * duration).toLong() } ?: position
            Text(formatTime(shown), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Text(formatTime(duration), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
