package com.pulse.player.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

// client_id официального приложения Яндекс Музыки — после входа Яндекс отдаёт токен в адресе
private const val OAUTH_URL =
    "https://oauth.yandex.ru/authorize?response_type=token&client_id=23cabbbdc6cd418abb4b39c32c41195d"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginScreen(onToken: (String) -> Unit, onClose: () -> Unit) {
    val tokenCallback by rememberUpdatedState(onToken)
    var manual by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .systemBarsPadding(),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Закрыть") }
            Text("Вход в Яндекс", style = MaterialTheme.typography.titleLarge)
        }

        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    webViewClient = object : WebViewClient() {
                        private fun check(url: String?): Boolean {
                            val match = Regex("access_token=([^&]+)").find(url ?: return false) ?: return false
                            tokenCallback(match.groupValues[1])
                            return true
                        }

                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean =
                            check(request?.url?.toString())

                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            if (check(url)) view?.stopLoading() else super.onPageStarted(view, url, favicon)
                        }
                    }
                    loadUrl(OAUTH_URL)
                }
            },
        )

        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = manual,
                onValueChange = { manual = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("…или вставь токен вручную") },
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { if (manual.isNotBlank()) tokenCallback(manual.trim()) }) { Text("OK") }
        }
    }
}
