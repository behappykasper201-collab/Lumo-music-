package com.pulse.player.data

import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.IOException
import org.schabi.newpipe.extractor.downloader.Request as NpRequest
import org.schabi.newpipe.extractor.downloader.Response as NpResponse

/** Сетевой слой для NewPipe Extractor на OkHttp. */
object NpDownloader : Downloader() {
    override fun execute(request: NpRequest): NpResponse {
        val method = request.httpMethod()
        val data = request.dataToSend()
        val body = when {
            data != null -> data.toRequestBody()
            method == "POST" -> ByteArray(0).toRequestBody()
            else -> null
        }
        val b = Request.Builder()
            .url(request.url())
            .method(method, body)
            .header("User-Agent", Http.UA)
        for ((key, values) in request.headers()) {
            b.removeHeader(key)
            values.forEach { b.addHeader(key, it) }
        }
        Http.client.newCall(b.build()).execute().use { r ->
            if (r.code == 429) throw ReCaptchaException("Слишком много запросов", request.url())
            return NpResponse(r.code, r.message, r.headers.toMultimap(), r.body?.string(), r.request.url.toString())
        }
    }
}

object SoundCloud {

    fun init() {
        NewPipe.init(NpDownloader)
    }

    fun search(query: String): List<Track> {
        val ex = ServiceList.SoundCloud.getSearchExtractor(query, listOf("tracks"), "")
        ex.fetchPage()
        return ex.initialPage.items.filterIsInstance<StreamInfoItem>().map { it.toTrack() }
    }

    private fun StreamInfoItem.toTrack(): Track = Track(
        id = url,
        source = Source.SOUNDCLOUD,
        title = name,
        artist = uploaderName ?: "",
        coverUrl = thumbnails.maxByOrNull { it.height }?.url?.replace("-large.", "-t500x500."),
        durationMs = if (duration > 0) duration * 1000 else 0,
    )

    /** Возвращает ссылку на аудио и флаг «это HLS-поток». */
    fun resolve(url: String): Pair<String, Boolean> {
        val streams = StreamInfo.getInfo(ServiceList.SoundCloud, url).audioStreams
        streams.firstOrNull { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.isUrl }
            ?.let { return it.content to false }
        streams.firstOrNull { it.deliveryMethod == DeliveryMethod.HLS && it.isUrl }
            ?.let { return it.content to true }
        throw IOException("трек недоступен для прослушивания")
    }
}
