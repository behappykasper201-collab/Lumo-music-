package com.pulse.player.data

import android.content.Context
import android.content.SharedPreferences
import com.pulse.player.PulseApp

/** Все пасхалки, счётчики и достижения. */
object Eggs {

    data class Egg(val id: String, val title: String, val hint: String)

    val all = listOf(
        Egg("tap_logo", "Секретная тема «Радуга»", "Логотип любит внимание"),
        Egg("search_lumo", "Найти самого себя", "Поищи меня"),
        Egg("search_42", "Ответ на главный вопрос", "Жизнь, вселенная и всё такое"),
        Egg("search_rick", "Ты знаешь правила", "Never gonna…"),
        Egg("search_dvd", "Прыгающий логотип", "Старые телевизоры"),
        Egg("search_snow", "Снегопад", "Зима близко"),
        Egg("search_party", "Вечеринка", "Позови всех"),
        Egg("search_roll", "Бочка", "Do a…"),
        Egg("search_hello", "hello world", "Первые слова программиста"),
        Egg("search_egg", "Пасхалка про пасхалки", "Очевидный запрос"),
        Egg("search_matrix", "Красная таблетка", "Проснись, Нео"),
        Egg("search_love", "Любовь", "Самое тёплое слово"),
        Egg("shake", "Потряси меня", "Телефон тоже любит танцевать"),
        Egg("vinyl_scratch", "DJ-скретч", "Винил и много нажатий"),
        Egg("long_press_wave", "Тайное послание", "Подержи волну"),
        Egg("wave_spam", "Нетерпеливый", "Волна, волна, волна, волна, волна"),
        Egg("night_owl", "Сова", "Музыка в 3 часа ночи"),
        Egg("midnight", "Полночь", "Ровно в 00:00"),
        Egg("leet", "13:37", "Время элиты"),
        Egg("rare_phrase", "Редкая фраза", "Повезёт при запуске"),
        Egg("tracks_100", "Сотня", "Дослушай 100 треков"),
        Egg("tracks_1000", "Меломан", "Дослушай 1000 треков"),
        Egg("likes_50", "Сердцеед", "50 лайков"),
        Egg("new_year", "Новый год", "Зайди в праздники"),
        Egg("halloween", "Хэллоуин", "31 октября"),
        Egg("april_fools", "Первоапрельский", "1 апреля"),
        Egg("friday13", "Пятница, 13-е", "Не бойся"),
        Egg("achievements", "Коллекционер", "Найди этот список"),
    )

    private lateinit var prefs: SharedPreferences
    private val found = mutableSetOf<String>()

    fun init(context: Context) {
        prefs = context.getSharedPreferences("eggs", Context.MODE_PRIVATE)
        found += prefs.getStringSet("found", emptySet()).orEmpty()
    }

    @Synchronized fun isFound(id: String) = id in found
    @Synchronized fun foundCount() = found.size

    /** Отмечает пасхалку найденной. Возвращает true, если впервые. */
    @Synchronized
    fun find(id: String, silent: Boolean = false): Boolean {
        if (id in found) return false
        val egg = all.firstOrNull { it.id == id } ?: return false
        found += id
        prefs.edit().putStringSet("found", found.toSet()).apply()
        if (!silent) PulseApp.instance.toast("🥚 Пасхалка: ${egg.title}  (${found.size}/${all.size})")
        return true
    }

    /** Дослушанный трек. Вехи — с поздравлениями. */
    @Synchronized
    fun countTrack() {
        val n = prefs.getInt("tracks", 0) + 1
        prefs.edit().putInt("tracks", n).apply()
        when (n) {
            10 -> PulseApp.instance.toast("10 треков! Разогрелись 🔥")
            50 -> PulseApp.instance.toast("50 треков. Волна тебя уже узнаёт")
            100 -> find("tracks_100")
            500 -> PulseApp.instance.toast("500 треков. Это уже серьёзно 🎧")
            1000 -> find("tracks_1000")
        }
    }

    @Synchronized
    fun countLike() {
        val n = prefs.getInt("likes", 0) + 1
        prefs.edit().putInt("likes", n).apply()
        if (n == 50) find("likes_50")
    }

    @Synchronized fun tracks() = prefs.getInt("tracks", 0)
}
