package com.pulse.player.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

/**
 * Твой вкус, который приложение запоминает само:
 * дослушал трек → исполнителю +1, пропустил в первые 30 сек → −1,
 * лайк → +3, дизлайк → −5. Исполнители с рейтингом ≤ −3 в волну не попадают,
 * а любимые чаще используются для подбора SoundCloud.
 */
object Taste {
    private lateinit var prefs: SharedPreferences
    private val scores = mutableMapOf<String, Int>()
    private val likes = mutableSetOf<String>()
    private val dislikes = mutableSetOf<String>()

    fun init(context: Context) {
        prefs = context.getSharedPreferences("taste", Context.MODE_PRIVATE)
        runCatching {
            val o = JSONObject(prefs.getString("scores", "{}") ?: "{}")
            o.keys().forEach { scores[it] = o.optInt(it) }
        }
        likes += prefs.getStringSet("likes", emptySet()).orEmpty()
        dislikes += prefs.getStringSet("dislikes", emptySet()).orEmpty()
    }

    private fun key(artist: String) = artist.substringBefore(",").trim().lowercase()

    @Synchronized
    fun record(artist: String, delta: Int) {
        val k = key(artist)
        if (k.isEmpty()) return
        scores[k] = ((scores[k] ?: 0) + delta).coerceIn(-10, 40)
        save()
    }

    @Synchronized
    fun score(artist: String): Int = scores[key(artist)] ?: 0

    fun disliked(artist: String) = score(artist) <= -3

    /** Несколько случайных исполнителей из любимых. */
    @Synchronized
    fun favorites(n: Int): List<String> =
        scores.entries.filter { it.value >= 2 }
            .sortedByDescending { it.value }
            .take(25)
            .map { it.key }
            .shuffled()
            .take(n)

    @Synchronized fun isLiked(mediaId: String) = mediaId in likes
    @Synchronized fun isDisliked(mediaId: String) = mediaId in dislikes

    @Synchronized
    fun setLiked(mediaId: String, value: Boolean) {
        if (value) {
            likes += mediaId
            dislikes -= mediaId
        } else {
            likes -= mediaId
        }
        save()
    }

    @Synchronized
    fun setDisliked(mediaId: String, value: Boolean) {
        if (value) {
            dislikes += mediaId
            likes -= mediaId
        } else {
            dislikes -= mediaId
        }
        save()
    }

    private fun save() {
        prefs.edit()
            .putString("scores", JSONObject(scores.toMap()).toString())
            .putStringSet("likes", likes.toSet())
            .putStringSet("dislikes", dislikes.toSet())
            .apply()
    }
}
