package com.pulse.player.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.withFrameNanos
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sin
import kotlin.random.Random

enum class EggOverlay { SNOW, CONFETTI, DVD, MATRIX, HEARTS }

private fun tri(x: Float): Float = 1f - abs((x % 2f) - 1f)

/** Слой пасхалок поверх интерфейса. Касания проходят сквозь него. */
@Composable
fun EggOverlayLayer(kind: EggOverlay?) {
    if (kind == null) return
    key(kind) {
        val t by produceState(0f) {
            val start = withFrameNanos { it }
            while (true) withFrameNanos { value = (it - start) / 1_000_000_000f }
        }
        val seeds = remember { List(90) { Triple(Random.nextFloat(), Random.nextFloat(), Random.nextFloat()) } }
        val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE } }
        val confetti = remember {
            listOf(0xFFFF4FA3, 0xFF00E5FF, 0xFFFFD600, 0xFF7CFF4F, 0xFFB14DFF, 0xFFFF8A3D, 0xFFFFFFFF).map { Color(it) }
        }

        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            when (kind) {
                EggOverlay.SNOW -> seeds.forEachIndexed { i, (sx, sy, sz) ->
                    val y = ((sy + t * (0.04f + sz * 0.08f)) % 1.05f) * h
                    val x = sx * w + sin(t * 1.2f + i) * 14.dp.toPx()
                    drawCircle(Color.White.copy(alpha = 0.55f + sz * 0.4f), (1.5f + sz * 3f).dp.toPx(), Offset(x, y))
                }
                EggOverlay.CONFETTI -> seeds.forEachIndexed { i, (sx, sy, sz) ->
                    val y = ((sy + t * (0.22f + sz * 0.25f)) % 1.15f - 0.08f) * h
                    val x = sx * w + sin(t * 2.5f + i) * 24.dp.toPx()
                    val c = confetti[i % confetti.size]
                    rotate(t * 220f * (if (i % 2 == 0) 1 else -1) + i * 30f, Offset(x, y)) {
                        drawRect(c, Offset(x - 4.dp.toPx(), y - 2.dp.toPx()), Size(8.dp.toPx(), 4.dp.toPx()))
                    }
                }
                EggOverlay.DVD -> {
                    val bw = 128.dp.toPx()
                    val bh = 60.dp.toPx()
                    val spanX = (w - bw).coerceAtLeast(1f)
                    val spanY = (h - bh).coerceAtLeast(1f)
                    val px = t * 220.dp.toPx() / spanX
                    val py = t * 160.dp.toPx() / spanY
                    val x = tri(px) * spanX
                    val y = tri(py) * spanY
                    val bounces = floor(px) + floor(py)
                    val c = Color.hsv((bounces * 67f) % 360f, 0.8f, 1f)
                    drawRoundRect(c, Offset(x, y), Size(bw, bh), CornerRadius(30.dp.toPx()))
                    drawIntoCanvas {
                        paint.color = Color.Black.toArgb()
                        paint.textSize = 26.dp.toPx()
                        paint.textAlign = Paint.Align.CENTER
                        paint.isFakeBoldText = true
                        it.nativeCanvas.drawText("lumo", x + bw / 2, y + bh / 2 + 9.dp.toPx(), paint)
                    }
                }
                EggOverlay.MATRIX -> {
                    val glyphs = "ｱｲｳｴｵｶｷｸｹｺ01LUMOﾗﾘﾙﾚﾛ"
                    val step = 18.dp.toPx()
                    val cols = (w / step).toInt() + 1
                    paint.textSize = 15.dp.toPx()
                    paint.textAlign = Paint.Align.CENTER
                    paint.isFakeBoldText = false
                    drawIntoCanvas { canvas ->
                        for (c in 0 until cols) {
                            val (s1, s2, s3) = seeds[c % seeds.size]
                            val head = ((s1 + t * (0.25f + s2 * 0.35f)) % 1.4f) * h
                            for (k in 0 until 14) {
                                val y = head - k * step
                                if (y < -step || y > h + step) continue
                                val a = if (k == 0) 1f else (1f - k / 14f) * 0.8f
                                paint.color = (if (k == 0) Color(0xFFCCFFDD) else Color(0xFF00FF66)).copy(alpha = a).toArgb()
                                val ch = glyphs[((c * 7 + k * 3 + (t * 6 * s3).toInt()) % glyphs.length)]
                                canvas.nativeCanvas.drawText(ch.toString(), c * step + step / 2, y, paint)
                            }
                        }
                    }
                }
                EggOverlay.HEARTS -> drawIntoCanvas { canvas ->
                    paint.textAlign = Paint.Align.CENTER
                    seeds.take(28).forEachIndexed { i, (sx, sy, sz) ->
                        val y = h - ((sy + t * (0.12f + sz * 0.12f)) % 1.15f) * h
                        val x = sx * w + sin(t * 1.5f + i) * 18.dp.toPx()
                        paint.textSize = (16f + sz * 22f).dp.toPx()
                        paint.color = Color(if (i % 3 == 0) 0xFFFF4FA3 else 0xFFFF1744).copy(alpha = 0.85f).toArgb()
                        canvas.nativeCanvas.drawText("❤", x, y, paint)
                    }
                }
            }
        }
    }
}
