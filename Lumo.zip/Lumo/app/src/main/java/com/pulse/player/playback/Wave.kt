package com.pulse.player.playback

import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import com.pulse.player.data.SoundCloud
import com.pulse.player.data.Taste
import com.pulse.player.data.Track
import com.pulse.player.data.WaveDiversity
import com.pulse.player.data.WaveLanguage
import com.pulse.player.data.WaveMood
import com.pulse.player.data.YandexMusic
import com.pulse.player.data.toMediaItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections
import kotlin.math.roundToInt

data class WaveConfig(
    val mood: WaveMood = WaveMood.ALL,
    val diversity: WaveDiversity = WaveDiversity.DEFAULT,
    val language: WaveLanguage = WaveLanguage.ANY,
    val scShare: Float = 0.35f,
)

/**
 * «Моя волна» вперемешку: волна Яндекса + треки SoundCloud.
 * Яндекс сам учится по отзывам (дослушал / пропустил / лайк / дизлайк),
 * а SoundCloud подбирается по исполнителям из волны и твоим любимым исполнителям (Taste).
 */
object Wave {
    @Volatile var active = false
    @Volatile var batchId: String? = null
    @Volatile var config = WaveConfig()
    private var loading = false

    private val playedSc: MutableSet<String> = Collections.synchronizedSet(mutableSetOf())

    fun reset() {
        playedSc.clear()
        batchId = null
    }

    fun yandexId(item: MediaItem?): String? =
        item?.mediaId?.takeIf { it.startsWith("YANDEX|") }?.substringAfter("|")

    private fun genreSeeds(c: WaveConfig): List<String> {
        val base = when (c.mood) {
            WaveMood.CALM -> listOf("chill", "lofi", "ambient", "acoustic", "dream pop", "slowed", "bedroom pop")
            WaveMood.ACTIVE -> listOf("phonk", "drum and bass", "edm", "hardstyle", "workout", "trap", "jersey club")
            WaveMood.FUN -> listOf("dance", "party", "funk", "disco", "house", "pop", "afrobeats")
            WaveMood.SAD -> listOf("sad", "emo rap", "melancholic", "sad piano", "slowed reverb", "indie sad")
            WaveMood.ALL -> listOf(
                "phonk", "lofi", "hip hop", "house", "drum and bass", "indie", "rock", "pop",
                "techno", "trap", "chill", "rnb", "synthwave", "hyperpop",
            )
        }
        return when (c.language) {
            WaveLanguage.RUSSIAN -> base.map { "русский $it" }
            WaveLanguage.NO_WORDS -> base.map { "$it instrumental" }
            else -> base
        }
    }

    /** Собирает очередную порцию волны. Вызывать не в главном потоке. */
    suspend fun buildBatch(api: YandexMusic, loggedIn: Boolean, lastYandexId: String?, known: Set<String>): List<MediaItem> =
        coroutineScope {
            val c = config
            val share = c.scShare.coerceIn(0f, 1f)

            val yandexAll: List<Track> = if (loggedIn) {
                try {
                    val (tracks, batch) = api.waveTracks(lastYandexId)
                    batch?.let { batchId = it }
                    tracks.filter { it.id !in known && !Taste.disliked(it.artist) && !Taste.isDisliked("YANDEX|${it.id}") }
                } catch (e: Exception) {
                    emptyList()
                }
            } else {
                emptyList()
            }

            val scCount = when {
                yandexAll.isEmpty() || share >= 0.99f -> 5
                share <= 0.01f -> 0
                else -> (yandexAll.size * share / (1f - share)).roundToInt().coerceIn(1, 6)
            }
            val yandex = if (share >= 0.99f) emptyList() else yandexAll

            val waveArtists = yandexAll.map { it.artist.substringBefore(",").trim() }
                .filter { it.isNotBlank() }.distinct().shuffled()
            val favs = Taste.favorites(scCount)
            val genres = genreSeeds(c).shuffled()

            val seeds = when {
                c.diversity == WaveDiversity.DISCOVER -> genres
                c.diversity == WaveDiversity.FAVORITE -> (favs + waveArtists + genres).distinct()
                waveArtists.isEmpty() -> (favs.take(scCount / 2) + genres).distinct()
                else -> (waveArtists.take(scCount - scCount / 3) + favs.take(scCount / 3) + genres).distinct()
            }.take(scCount)

            val discover = c.diversity == WaveDiversity.DISCOVER
            val sc = seeds.map { seed ->
                async { runCatching { randomScTrack(seed, discover) }.getOrNull() }
            }.awaitAll().filterNotNull()

            val result = yandex.map { it.toMediaItem() }.toMutableList()
            sc.forEach { item -> result.add((0..result.size).random(), item) }
            result
        }

    private fun randomScTrack(seed: String, discover: Boolean): MediaItem? {
        val candidates = SoundCloud.search(seed)
            .take(20)
            .filter {
                it.id !in playedSc &&
                    it.durationMs in 60_000..600_000 &&
                    !Taste.disliked(it.artist) &&
                    !Taste.isDisliked("SOUNDCLOUD|${it.id}") &&
                    (!discover || Taste.score(it.artist) == 0)
            }
            // любимые исполнители — чуть выше шанс
            .sortedByDescending { Taste.score(it.artist) + (0..3).random() }
        for (t in candidates.take(3)) {
            val resolved = runCatching { SoundCloud.resolve(t.id) }.getOrNull() ?: continue
            playedSc.add(t.id)
            return t.toMediaItem(resolved.first, resolved.second)
        }
        return null
    }

    fun onTransition(player: Player, item: MediaItem?, scope: CoroutineScope, api: YandexMusic, loggedIn: Boolean) {
        if (!active) return

        yandexId(item)?.let { id ->
            val album = item?.mediaMetadata?.extras?.getString("albumId")
            val full = if (album != null) "$id:$album" else id
            val batch = batchId
            scope.launch(Dispatchers.IO) { api.waveFeedback("trackStarted", batch, full) }
        }

        val count = player.mediaItemCount
        if (loading || count == 0 || count - player.currentMediaItemIndex > 3) return
        loading = true

        val recent = (maxOf(0, count - 40) until count).map { player.getMediaItemAt(it) }
        val known = recent.mapNotNull { yandexId(it) }.toSet()
        val lastYandex = recent.lastOrNull { yandexId(it) != null }?.let { yandexId(it) }

        scope.launch {
            try {
                val items = withContext(Dispatchers.IO) { buildBatch(api, loggedIn, lastYandex, known) }
                if (active && items.isNotEmpty()) player.addMediaItems(items)
            } catch (_: Exception) {
                // попробуем на следующем треке
            } finally {
                loading = false
            }
        }
    }
}
